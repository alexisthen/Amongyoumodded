/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Title extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Logo3", "./Title/costumes/Logo3.svg", {
        x: 210.20013,
        y: 59.39167539358746,
      }),
    ];

    this.sounds = [new Sound("pop", "./Title/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickColor" },
        this.whenIReceivePickcolor
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 115);
    this.costume = "Logo3";
    this.visible = true;
    this.moveAhead();
  }

  *whenIReceiveShowRole() {
    this.visible = false;
  }

  *whenIReceivePickcolor() {
    this.visible = false;
  }
}
