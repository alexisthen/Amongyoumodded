/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Impostor extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Purple", "./Impostor/costumes/Purple.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("Pink", "./Impostor/costumes/Pink.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("Red", "./Impostor/costumes/Red.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("Orange", "./Impostor/costumes/Orange.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("Yellow", "./Impostor/costumes/Yellow.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("Lime", "./Impostor/costumes/Lime.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("Cyan", "./Impostor/costumes/Cyan.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("Brown", "./Impostor/costumes/Brown.svg", {
        x: 45.75079499999998,
        y: 6.9307450000000586,
      }),
      new Costume("Blue", "./Impostor/costumes/Blue.svg", {
        x: 45.75081499999999,
        y: 6.930755000000005,
      }),
      new Costume("Green", "./Impostor/costumes/Green.svg", {
        x: 45.75079499999998,
        y: 6.9307450000000586,
      }),
      new Costume("Black", "./Impostor/costumes/Black.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
      new Costume("White", "./Impostor/costumes/White.svg", {
        x: 45.750804999999986,
        y: 6.93074500000003,
      }),
    ];

    this.sounds = [new Sound("pop", "./Impostor/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.visible = false;
    while (true) {
      this.costume = this.stage.vars.impostor;
      yield;
    }
  }

  *whenIReceiveDefeat() {
    this.effects.brightness = -100;
    if (this.toNumber(this.stage.vars.votedwrong) === 0) {
      yield* this.wait(3);
    }
    this.visible = true;
    for (let i = 0; i < 34; i++) {
      this.moveAhead();
      this.effects.brightness += 3;
      yield;
    }
  }
}
