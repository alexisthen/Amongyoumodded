/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Voted extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Voted/costumes/costume1.svg", {
        x: 253.5,
        y: 188,
      }),
      new Costume("costume2", "./Voted/costumes/costume2.svg", {
        x: 253.5,
        y: 188,
      }),
    ];

    this.sounds = [new Sound("pop", "./Voted/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "Voted" }, this.whenIReceiveVoted),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Skipped" },
        this.whenIReceiveSkipped
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Skipped" },
        this.whenIReceiveSkipped2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.voted.visible = false;
    this.visible = false;
    while (true) {
      this.moveAhead();
      yield;
    }
  }

  *whenIReceiveVoted() {
    this.stage.vars.game = 0;
    this.stage.watchers.mode.visible = false;
    this.costume = "costume1";
    this.stage.watchers.evidence.visible = false;
    this.stage.watchers.voted.visible = true;
    this.effects.brightness = -100;
    this.visible = true;
    for (let i = 0; i < 34; i++) {
      this.effects.brightness += 3;
      yield;
    }
    yield* this.wait(2);
    this.stage.watchers.voted.visible = false;
    for (let i = 0; i < 34; i++) {
      this.effects.brightness -= 3;
      yield;
    }
    yield* this.wait(2);
    this.visible = false;
  }

  *whenIReceiveSkipped() {
    this.stage.vars.aVariable = 1;
    if (this.toString(this.stage.vars.mode) === "Mobile Mode") {
      this.stage.vars.mobileMode = 0;
      while (!(this.toNumber(this.stage.vars.aVariable) === 0)) {
        yield;
      }
      this.stage.vars.mobileMode = 1;
    }
  }

  *whenIReceiveSkipped2() {
    this.stage.watchers.mode.visible = false;
    this.stage.watchers.voted.visible = false;
    this.costume = "costume2";
    this.stage.watchers.evidence.visible = false;
    this.effects.brightness = -100;
    this.visible = true;
    for (let i = 0; i < 34; i++) {
      this.effects.brightness += 3;
      yield;
    }
    yield* this.wait(2);
    for (let i = 0; i < 34; i++) {
      this.effects.brightness -= 3;
      yield;
    }
    yield* this.wait(2);
    this.visible = false;
    this.stage.watchers.mode.visible = true;
    this.stage.vars.aVariable = 0;
  }

  *whenIReceiveEmergencyMeeting() {
    this.stage.watchers.mode.visible = false;
    this.stage.vars.aVariable = 1;
    if (this.toString(this.stage.vars.mode) === "Mobile Mode") {
      this.stage.vars.mobileMode = 0;
      while (!(this.toNumber(this.stage.vars.aVariable) === 0)) {
        yield;
      }
      this.stage.vars.mobileMode = 1;
    }
  }

  *whenIReceiveStopmeeting() {
    this.stage.watchers.mode.visible = true;
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    yield* this.sayAndWait("check my yt out its in the instruction", 2);
  }
}
