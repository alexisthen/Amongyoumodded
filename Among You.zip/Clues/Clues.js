/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Clues extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Office", "./Clues/costumes/Office.svg", {
        x: 6.220836334742529,
        y: 54.66185840093988,
      }),
      new Costume("West Power", "./Clues/costumes/West Power.svg", {
        x: -103.73889666666656,
        y: 43.38661000000002,
      }),
      new Costume("Office  ", "./Clues/costumes/Office  .svg", {
        x: 38.92777166666659,
        y: 87.05326333333332,
      }),
      new Costume("Navigation", "./Clues/costumes/Navigation.svg", {
        x: -0.40556333333327643,
        y: -89.6133900000001,
      }),
      new Costume("Office ", "./Clues/costumes/Office .svg", {
        x: -29.072206951344583,
        y: 119.05327333333332,
      }),
      new Costume("Kitchen", "./Clues/costumes/Kitchen.svg", {
        x: -66.73890826070084,
        y: 12.053276666666733,
      }),
      new Costume("Storage", "./Clues/costumes/Storage.svg", {
        x: -194.40556748266437,
        y: 28.386599999999987,
      }),
      new Costume("Kitchen ", "./Clues/costumes/Kitchen .svg", {
        x: -70.40556492736732,
        y: -23.2800583333333,
      }),
      new Costume("Office   ", "./Clues/costumes/Office   .svg", {
        x: 56.594438369649765,
        y: 102.053275,
      }),
      new Costume("Security", "./Clues/costumes/Security.svg", {
        x: 123.92777170298297,
        y: -82.6133916666667,
      }),
      new Costume("Repairs", "./Clues/costumes/Repairs.svg", {
        x: -103.73889659403414,
        y: -91.61338999999998,
      }),
      new Costume("Office     ", "./Clues/costumes/Office     .svg", {
        x: -34.77594499999998,
        y: 96.83105,
      }),
      new Costume("East Power", "./Clues/costumes/East Power.svg", {
        x: 105.59443170298297,
        y: 43.38660999999999,
      }),
      new Costume("Navigation  ", "./Clues/costumes/Navigation  .svg", {
        x: -21.627794999999992,
        y: -39.65042500000001,
      }),
      new Costume("Office    ", "./Clues/costumes/Office    .svg", {
        x: -34.59075999999999,
        y: 39.23846499999999,
      }),
      new Costume("West Power ", "./Clues/costumes/West Power .svg", {
        x: -99.22039000000001,
        y: 75.905125,
      }),
      new Costume("Storage ", "./Clues/costumes/Storage .svg", {
        x: -199.59076,
        y: 62.016234999999995,
      }),
    ];

    this.sounds = [new Sound("pop", "./Clues/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Victory" },
        this.whenIReceiveVictory
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.CLONE_START, this.startAsClone4),
      new Trigger(
        Trigger.BROADCAST,
        { name: "ClueFound" },
        this.whenIReceiveCluefound
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame3
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone5),
    ];

    this.vars.costume = 8;
  }

  *startAsClone() {
    this.moveAhead();
    while (true) {
      this.goto(
        this.toNumber(this.stage.vars.playerX) +
          this.toNumber(this.stage.vars.mapX),
        this.toNumber(this.stage.vars.playerY) +
          this.toNumber(this.stage.vars.mapY)
      );
      yield;
    }
  }

  *whenIReceiveBeginGame() {}

  *whenGreenFlagClicked() {}

  *startAsClone2() {
    while (true) {
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        this.stage.vars.clue = 1;
      }
      yield;
    }
  }

  *decodeCluecolor() {
    if (this.toNumber(this.stage.vars.cluecolor) === 1) {
      this.stage.vars.cluecolor = "Purple";
    } else {
      if (this.toNumber(this.stage.vars.cluecolor) === 2) {
        this.stage.vars.cluecolor = "Pink";
      } else {
        if (this.toNumber(this.stage.vars.cluecolor) === 3) {
          this.stage.vars.cluecolor = "Red";
        } else {
          if (this.toNumber(this.stage.vars.cluecolor) === 4) {
            this.stage.vars.cluecolor = "Orange";
          } else {
            if (this.toNumber(this.stage.vars.cluecolor) === 5) {
              this.stage.vars.cluecolor = "Yellow";
            } else {
              if (this.toNumber(this.stage.vars.cluecolor) === 6) {
                this.stage.vars.cluecolor = "Lime";
              } else {
                if (this.toNumber(this.stage.vars.cluecolor) === 7) {
                  this.stage.vars.cluecolor = "Cyan";
                } else {
                  if (this.toNumber(this.stage.vars.cluecolor) === 8) {
                    this.stage.vars.cluecolor = "Brown";
                  } else {
                    if (this.toNumber(this.stage.vars.cluecolor) === 9) {
                      this.stage.vars.cluecolor = "Blue";
                    } else {
                      if (this.toNumber(this.stage.vars.cluecolor) === 10) {
                        this.stage.vars.cluecolor = "Green";
                      } else {
                        if (this.toNumber(this.stage.vars.cluecolor) === 11) {
                          this.stage.vars.cluecolor = "Black";
                        } else {
                          if (this.toNumber(this.stage.vars.cluecolor) === 12) {
                            this.stage.vars.cluecolor = "White";
                          } else {
                            null;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  *whenIReceiveEmergencyMeeting() {
    this.visible = false;
  }

  *whenIReceiveVictory() {
    this.deleteThisClone();
  }

  *whenIReceiveDefeat() {
    this.deleteThisClone();
  }

  *whenIReceiveStopmeeting() {
    this.visible = true;
  }

  *whenIReceiveBeginGame2() {
    this.visible = true;
  }

  *whenGreenFlagClicked2() {
    this.goto(0, 0);
    this.visible = false;
    this.moveBehind();
    this.costume = this.random(1, 17);
    this.vars.costume = this.costumeNumber;
    this.costume = "Office";
    this.size = 800;
    this.costume = this.vars.costume;
  }

  *startAsClone3() {
    while (true) {
      for (let i = 0; i < 10; i++) {
        this.effects.ghost += 10;
        yield;
      }
      yield* this.wait(2);
      for (let i = 0; i < 10; i++) {
        this.effects.ghost -= 10;
        yield;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.stage.vars.deadplayers = [];
    this.stage.vars.evidence = [];
    this.stage.vars.players = [];
    this.stage.vars.players.push(1);
    this.stage.vars.players.push(2);
    this.stage.vars.players.push(3);
    this.stage.vars.players.push(4);
    this.stage.vars.players.push(5);
    this.stage.vars.players.push(6);
    this.stage.vars.players.push(7);
    this.stage.vars.players.push(8);
    this.stage.vars.players.push(9);
    this.stage.vars.players.push(10);
    this.stage.vars.players.push(11);
    this.stage.vars.players.push(12);
  }

  *whenGreenFlagClicked4() {
    this.stage.vars.game = 0;
    while (!(this.toNumber(this.stage.vars.game) === 1)) {
      yield;
    }
    this.stage.vars.players.splice(this.stage.vars.player - 1, 1);
    this.stage.vars.impostorNumber = this.random(1, 11);
    this.stage.vars.impostor = this.itemOf(
      this.stage.vars.players,
      this.stage.vars.impostorNumber - 1
    );
    this.stage.vars.players.splice(this.stage.vars.impostorNumber - 1, 1);
    for (let i = 0; i < this.random(4, 5); i++) {
      this.stage.vars.dead = this.random(1, this.stage.vars.players.length);
      this.stage.vars.deadplayers.push(
        this.itemOf(this.stage.vars.players, this.stage.vars.dead - 1)
      );
      this.stage.vars.players.splice(this.stage.vars.dead - 1, 1);
      yield;
    }
  }

  *startAsClone4() {
    while (!(this.toNumber(this.stage.vars.evidence.join(" ")) === 10)) {
      yield;
    }
    yield* this.wait(1);
    this.deleteThisClone();
  }

  *whenIReceiveCluefound() {
    if (
      this.toNumber(this.stage.vars.searching) === 0 &&
      this.touching(this.sprites["Playerdetect"].andClones()) &&
      this.toNumber(this.stage.vars.cluecheck) === 0
    ) {
      this.stage.vars.cluecolornum = this.random(
        1,
        this.stage.vars.players.length
      );
      this.stage.vars.cluecolor = this.itemOf(
        this.stage.vars.players,
        this.stage.vars.cluecolornum - 1
      );
      this.stage.vars.players.splice(this.stage.vars.cluecolornum - 1, 1);
      yield* this.decodeCluecolor();
      if (this.random(1, 2) === 1) {
        this.stage.vars.evidence.push(
          this.toString(this.stage.vars.cluecolor) +
            (" DNA: " + this.costume.name)
        );
      } else {
        this.stage.vars.evidence.push(
          this.toString(this.stage.vars.cluecolor) +
            (" Fingerprints: " + this.costume.name)
        );
      }
      this.stage.vars.clue = 0;
      this.deleteThisClone();
    }
  }

  *whenIReceiveBeginGame3() {
    for (let i = 0; i < this.stage.vars.players.length; i++) {
      this.createClone();
      this.costumeNumber++;
      yield;
    }
    this.costume = "Navigation  ";
  }

  *startAsClone5() {
    while (true) {
      if (this.touching("edge")) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }
}
