/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Meeting extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Meeting/costumes/1.svg", {
        x: 198.7,
        y: -13.800004999999999,
      }),
      new Costume("2", "./Meeting/costumes/2.svg", {
        x: 141.291085,
        y: -125.53055999999998,
      }),
    ];

    this.sounds = [new Sound("pop", "./Meeting/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];

    this.vars.costume = 1;
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.goto(this.sprites["Walls"].x, this.sprites["Walls"].y);
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        this.stage.vars.use = 1;
      } else {
        this.stage.vars.use = 0;
      }
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    this.costume = this.stage.vars.gamemap;
    this.vars.costume = this.costumeNumber;
    this.costume = 1;
    this.size = 800;
    this.costume = this.vars.costume;
  }

  *whenGreenFlagClicked2() {
    this.effects.ghost = 100;
    this.visible = true;
  }
}
