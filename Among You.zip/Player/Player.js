/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Standing", "./Player/costumes/Standing.svg", {
        x: 40.084145000000035,
        y: 54.34553500000001,
      }),
      new Costume("Walking 1", "./Player/costumes/Walking 1.svg", {
        x: 47.808381232202066,
        y: 69.34553500000001,
      }),
      new Costume("Walking 5", "./Player/costumes/Walking 5.svg", {
        x: 47.80838123220204,
        y: 74.345535,
      }),
      new Costume("Walking 6", "./Player/costumes/Walking 6.svg", {
        x: 47.808397464403924,
        y: 69.34553500000001,
      }),
      new Costume("Walking 2", "./Player/costumes/Walking 2.svg", {
        x: 40.084145000000035,
        y: 54.34553500000001,
      }),
      new Costume("Walking 3", "./Player/costumes/Walking 3.svg", {
        x: 47.808387464404035,
        y: 69.34553500000001,
      }),
      new Costume("Walking 7", "./Player/costumes/Walking 7.svg", {
        x: 47.808386232202054,
        y: 73.345535,
      }),
      new Costume("Walking 8", "./Player/costumes/Walking 8.svg", {
        x: 47.808386232202054,
        y: 69.345535,
      }),
      new Costume("Walking 4", "./Player/costumes/Walking 4.svg", {
        x: 40.08413500000003,
        y: 54.34553500000001,
      }),
      new Costume("Dead 1", "./Player/costumes/Dead 1.svg", {
        x: 40.41749500000003,
        y: 26.72544032686463,
      }),
      new Costume("Dead 2", "./Player/costumes/Dead 2.svg", {
        x: 49.33620428571433,
        y: 4.776314320923319,
      }),
      new Costume("Ghost 1", "./Player/costumes/Ghost 1.svg", {
        x: 54.63088930232561,
        y: 54.34554,
      }),
      new Costume("Ghost 2", "./Player/costumes/Ghost 2.svg", {
        x: 56.63088930232573,
        y: 54.34554,
      }),
      new Costume("Ghost 3", "./Player/costumes/Ghost 3.svg", {
        x: 56.63089000000011,
        y: 54.34554,
      }),
      new Costume("Among You Hat", "./Player/costumes/Among You Hat.svg", {
        x: 41.30478306818185,
        y: 18.662400546345737,
      }),
      new Costume("walk", "./Player/costumes/walk.svg", { x: 240, y: 39.5 }),
    ];

    this.sounds = [
      new Sound("Footsteps", "./Player/sounds/Footsteps.wav"),
      new Sound("Footsteps2", "./Player/sounds/Footsteps2.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame3
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame4
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickColor" },
        this.whenIReceivePickcolor
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame5
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Victory" },
        this.whenIReceiveVictory
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "TP to enemy" },
        this.whenIReceiveTpToEnemy
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Teleport" },
        this.whenIReceiveTeleport
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    while (true) {
      if (this.toNumber(this.stage.vars.move) === 1) {
        this.costume = "Standing";
      }
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
    this.moveAhead();
    while (true) {
      this.goto(this.sprites["Playerdetect"].x, this.sprites["Playerdetect"].y);
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.direction = 90;
    this.costume = "Standing";
  }

  *whenIReceiveBeginGame2() {
    this.size = 40;
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Keyboard Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (
            this.keyPressed("up arrow") ||
            this.keyPressed("down arrow") ||
            this.keyPressed("w") ||
            this.keyPressed("s") ||
            this.keyPressed("d") ||
            this.keyPressed("a") ||
            this.keyPressed("left arrow") ||
            this.keyPressed("right arrow")
          ) {
            yield* this.startSound(this.random(1, 2));
            this.costume = "Walking 1";
            yield* this.wait(0.06);
            this.costume = "Walking 5";
            yield* this.wait(0.06);
            this.costume = "Walking 6";
            yield* this.wait(0.06);
            this.costume = "Walking 2";
            yield* this.wait(0.06);
            if (
              this.keyPressed("up arrow") ||
              this.keyPressed("down arrow") ||
              this.keyPressed("w") ||
              this.keyPressed("s") ||
              this.keyPressed("d") ||
              this.keyPressed("a") ||
              this.keyPressed("left arrow") ||
              this.keyPressed("right arrow")
            ) {
              yield* this.startSound(this.random(1, 2));
              this.costume = "Walking 3";
              yield* this.wait(0.06);
              this.costume = "Walking 7";
              yield* this.wait(0.06);
              this.costume = "Walking 8";
              yield* this.wait(0.06);
              this.costume = "Walking 4";
              yield* this.wait(0.06);
            }
          } else {
            this.costume = "Standing";
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveBeginGame3() {
    this.direction = 90;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Mobile Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (this.compare(this.stage.vars.jx, 0) < 0) {
            this.direction = -90;
          } else {
            if (this.compare(this.stage.vars.jx, 0) > 0) {
              this.direction = 90;
            } else {
              this.costume = "Standing";
            }
          }
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Mobile Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (
            !(this.toNumber(this.stage.vars.jx) === 0) ||
            !(this.toNumber(this.stage.vars.jy) === 0)
          ) {
            yield* this.startSound(this.random(1, 2));
            this.costume = "Walking 1";
            yield* this.wait(0.06);
            this.costume = "Walking 5";
            yield* this.wait(0.06);
            this.costume = "Walking 6";
            yield* this.wait(0.06);
            this.costume = "Walking 2";
            yield* this.wait(0.06);
            if (
              !(this.toNumber(this.stage.vars.jx) === 0) ||
              !(this.toNumber(this.stage.vars.jy) === 0)
            ) {
              yield* this.startSound(this.random(1, 2));
              this.costume = "Walking 3";
              yield* this.wait(0.06);
              this.costume = "Walking 7";
              yield* this.wait(0.06);
              this.costume = "Walking 8";
              yield* this.wait(0.06);
              this.costume = "Walking 4";
              yield* this.wait(0.06);
            }
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveShowRole() {
    this.moveAhead();
    this.visible = true;
    this.goto(0, -50);
    this.size = 70;
  }

  *whenIReceiveShowRole2() {
    this.visible = false;
    this.effects.brightness = -100;
    yield* this.wait(1);
    this.visible = true;
    for (let i = 0; i < 34; i++) {
      this.effects.brightness += 3;
      yield;
    }
    yield* this.wait(3);
    for (let i = 0; i < 34; i++) {
      this.effects.brightness -= 3;
      yield;
    }
    this.moveBehind();
    this.effects.clear();
  }

  *whenIReceiveBeginGame4() {
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Keyboard Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (this.keyPressed("a") || this.keyPressed("left arrow")) {
            this.direction = -90;
          }
          if (this.keyPressed("right arrow") || this.keyPressed("d")) {
            this.direction = 90;
          }
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      this.effects.color = this.toNumber(this.stage.vars.color);
      if (this.toNumber(this.stage.vars.color) === -120) {
        this.effects.brightness = -30;
      } else {
        if (this.toNumber(this.stage.vars.color) === -60) {
          this.effects.brightness = -30;
        } else {
          this.effects.brightness = 0;
        }
      }
      yield;
    }
  }

  *whenIReceivePickcolor() {
    this.moveAhead();
    this.goto(-100, 0);
    this.size = 200;
    this.visible = true;
  }

  *whenIReceiveBeginGame5() {
    this.visible = false;
    this.stage.vars.lights = 0;
    yield* this.wait(0.5);
    this.visible = true;
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveEmergencyMeeting() {
    this.direction = 90;
  }

  *whenIReceiveVictory() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = true;
    this.costume = "Standing";
    this.goto(0, -50);
    this.direction = 90;
    this.size = 80;
    for (let i = 0; i < 10; i++) {
      this.moveAhead();
      yield;
    }
  }

  *whenIReceiveStopmeeting() {
    this.direction = 90;
  }

  *whenIReceiveDefeat2() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveTpToEnemy() {
    this.goto(
      this.toNumber(this.stage.vars.enemyX),
      this.toNumber(this.stage.vars.enemyy)
    );
  }

  *whenIReceiveTeleport() {
    this.goto(this.random(-240, 240), this.random(-180, 180));
    this.stage.vars.playerX = this.random(-360, 150);
    this.stage.vars.playerY = this.random(-360, 150);
  }
}
