/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class MeetingBackground extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./MeetingBackground/costumes/costume1.svg", {
        x: 211.32786,
        y: 156.343765,
      }),
    ];

    this.sounds = [new Sound("pop", "./MeetingBackground/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.visible = false;
  }

  *whenIReceiveEmergencyMeeting() {
    this.stage.watchers.mode.visible = false;
    this.moveAhead();
    this.visible = true;
  }

  *whenIReceiveStopmeeting() {
    this.stage.vars.move = 0;
    this.stage.watchers.mode.visible = true;
    this.stage.watchers.evidence.visible = false;
  }

  *whenIReceiveStopmeeting2() {
    this.visible = false;
  }
}
