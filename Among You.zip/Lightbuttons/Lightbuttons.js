/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Lightbuttons extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Office", "./Lightbuttons/costumes/Office.svg", {
        x: 27.56061151515152,
        y: 100.53787636363636,
      }),
      new Costume("East Power", "./Lightbuttons/costumes/East Power.svg", {
        x: 128.89773151515152,
        y: 99.89393636363636,
      }),
      new Costume("West Power", "./Lightbuttons/costumes/West Power.svg", {
        x: -78.4848484848485,
        y: 101.15151636363636,
      }),
      new Costume("Report", "./Lightbuttons/costumes/Report.svg", {
        x: 0,
        y: 0,
      }),
      new Costume("Kitchen", "./Lightbuttons/costumes/Kitchen.svg", {
        x: 0,
        y: 0,
      }),
      new Costume("Repairs", "./Lightbuttons/costumes/Repairs.svg", {
        x: -80.67802848484848,
        y: -41.38258363636362,
      }),
      new Costume("Storage", "./Lightbuttons/costumes/Storage.svg", {
        x: 0,
        y: 0,
      }),
      new Costume("Navigation", "./Lightbuttons/costumes/Navigation.svg", {
        x: 25.367421515151534,
        y: -41.99621363636362,
      }),
      new Costume("Security", "./Lightbuttons/costumes/Security.svg", {
        x: 126.7045415151515,
        y: -42.640153636363664,
      }),
      new Costume("nothing", "./Lightbuttons/costumes/nothing.svg", {
        x: 0,
        y: 0,
      }),
      new Costume(
        "all the others",
        "./Lightbuttons/costumes/all the others.svg",
        { x: 224.62121, y: 68.696955 }
      ),
    ];

    this.sounds = [new Sound("pop", "./Lightbuttons/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.CLONE_START, this.startAsClone4),
      new Trigger(Trigger.CLONE_START, this.startAsClone5),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLONE_START, this.startAsClone6),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
    ];

    this.vars.clonenum = 10;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.vars.clonenum = 0;
    this.costume = "Office";
    this.goto(0, 0);
    for (let i = 0; i < 10; i++) {
      this.vars.clonenum++;
      this.createClone();
      this.costumeNumber++;
      yield;
    }
  }

  *whenthisspriteclicked() {}

  *startAsClone() {
    while (true) {
      if (this.toNumber(this.stage.vars.lightscooldown) === 0) {
        this.effects.brightness = 0;
      } else {
        this.effects.brightness = -30;
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      this.size = 80;
      if (this.toNumber(this.stage.vars.maptype) === 2) {
        this.visible = true;
        this.moveAhead();
        this.goto(0, 0);
      } else {
        this.goto(-300000000, -300000000000);
        this.moveBehind();
        this.visible = false;
      }
      yield;
    }
  }

  *whenthisspriteclicked2() {}

  *whenIReceiveBeginGame() {
    this.stage.vars.lightnum = 0;
    this.stage.vars.lightscooldown = 0;
  }

  *startAsClone3() {}

  *startAsClone4() {
    while (true) {
      if (this.mouse.down && this.touching("mouse")) {
        if (this.toNumber(this.stage.vars.lightscooldown) === 0) {
          if (this.toNumber(this.stage.vars.touchingmap) === 0) {
            this.stage.vars.lightnum = this.costumeNumber;
            this.stage.vars.lightscooldown = 20;
            while (!(this.toNumber(this.stage.vars.lightscooldown) === 0)) {
              this.stage.vars.lightscooldown--;
              yield* this.wait(1);
              yield;
            }
          }
        }
      }
      yield;
    }
  }

  *startAsClone5() {
    while (true) {
      if (this.mouse.down && this.touching("mouse")) {
        if (this.toNumber(this.stage.vars.touchingmap) === 0) {
          if (this.toNumber(this.stage.vars.lightscooldown) === 0) {
            yield* this.wait(10);
            this.stage.vars.lightnum = 0;
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveBeginGame2() {
    this.stage.vars.lightscooldown = 0;
  }

  *whenthisspriteclicked3() {
    this.stage.vars.joystick = 0;
    while (!!(this.mouse.down && this.touching("mouse"))) {
      yield;
    }
    this.stage.vars.joystick = 1;
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.joystick = 1;
  }

  *startAsClone6() {
    while (true) {
      while (!(this.toNumber(this.stage.vars.lightscooldown) === 10)) {
        yield;
      }
      this.stage.vars.lightnum = 0;
      this.stage.vars.lights = 0;
      yield;
    }
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
