/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Use extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Use/costumes/costume1.svg", {
        x: 60.77992806980939,
        y: 58.989347995137905,
      }),
    ];

    this.sounds = [
      new Sound("Buzz", "./Use/sounds/Buzz.wav"),
      new Sound("Afro String2", "./Use/sounds/Afro String2.wav"),
    ];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
    ];
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.evidence.visible = false;
    this.costume = "costume1";
    this.goto(178, -19);
    this.size = 80;
    this.visible = false;
  }

  *whenIReceiveBeginGame() {
    yield* this.wait(0.35);
    this.moveAhead();
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toNumber(this.stage.vars.game) === 1) {
        if (this.toNumber(this.stage.vars.use) === 1) {
          if (!this.touching(this.sprites["Teleporters"].andClones())) {
            this.moveAhead();
            this.visible = true;
          }
        } else {
          this.visible = false;
        }
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.toNumber(this.stage.vars.use) === 1) {
      if (!this.touching(this.sprites["Teleporters"].andClones())) {
        this.broadcast("Meeting");
      }
    }
  }

  *whenIReceiveStopmeeting() {
    this.goto(178, -19);
    this.costume = "costume1";
  }
}
