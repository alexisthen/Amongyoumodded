/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Walls extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Walls/costumes/costume1.svg", {
        x: 0.3437500000000284,
        y: 0.07499980926516514,
      }),
      new Costume("Map1", "./Walls/costumes/Map1.svg", {
        x: 254.521645,
        y: 179.31666,
      }),
      new Costume("Map2", "./Walls/costumes/Map2.svg", {
        x: 228.883165,
        y: 207.015635,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Leave game" },
        this.whenIReceiveLeaveGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame3
      ),
    ];

    this.vars.costume = 2;
  }

  *whenIReceiveLeaveGame() {}

  *whenGreenFlagClicked() {
    this.effects.ghost = 100;
    this.rotationStyle = Sprite.RotationStyle.DONT_ROTATE;
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.costume = "Map1";
    } else {
      this.costume = "Map2";
      this.stage.vars.playerX = 1090;
      this.stage.vars.playerY = 1110;
    }
    this.vars.costume = this.costumeNumber;
    this.costume = "costume1";
    this.size = 800;
    this.costume = this.vars.costume;
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.stage.vars.playerX = 1550;
      this.stage.vars.playerY = 215;
    } else {
      this.stage.vars.playerX = 1090;
      this.stage.vars.playerY = 1110;
    }
    while (true) {
      if (!this.touching(this.sprites["Vents"].andClones())) {
        this.stage.vars.ventnum = 0;
      }
      if (this.toNumber(this.stage.vars.move) === 0) {
        if (this.toString(this.stage.vars.mode) === "Keyboard Mode") {
          this.stage.vars.scroll = 0;
          this.goto(
            this.toNumber(this.stage.vars.playerX) +
              this.toNumber(this.stage.vars.mapX),
            this.toNumber(this.stage.vars.playerY) +
              this.toNumber(this.stage.vars.mapY)
          );
          if (this.keyPressed("right arrow") || this.keyPressed("d")) {
            this.stage.vars.playerX -= 10;
            this.x -= 10;
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerX += 10;
              this.x += 10;
            }
          }
          if (this.keyPressed("left arrow") || this.keyPressed("a")) {
            this.stage.vars.playerX += 10;
            this.x += 10;
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerX -= 10;
              this.x -= 10;
            }
          }
          if (this.keyPressed("up arrow") || this.keyPressed("w")) {
            this.stage.vars.playerY -= 10;
            this.y -= 10;
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerY += 10;
              this.y += 10;
            }
          }
          if (this.keyPressed("down arrow") || this.keyPressed("s")) {
            this.stage.vars.playerY += 10;
            this.y += 10;
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerY -= 10;
              this.y -= 10;
            }
          }
        } else {
          this.stage.vars.jspeed = 0;
          this.stage.vars.scroll = 0;
          if (this.compare(this.stage.vars.jy, 0) < 0) {
            this.stage.vars.playerY +=
              0 -
              (this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            this.y +=
              0 -
              (this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerY +=
                this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed);
              this.y +=
                this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed);
            }
          }
          if (this.compare(this.stage.vars.jx, 0) < 0) {
            this.stage.vars.playerX +=
              0 -
              (this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            this.x +=
              0 -
              (this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerX +=
                this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed);
              this.x +=
                this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed);
            }
          }
          if (this.compare(this.stage.vars.jy, 0) > 0) {
            this.stage.vars.playerY +=
              0 -
              (this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            this.y +=
              0 -
              (this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerY +=
                this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed);
              this.y +=
                this.toNumber(this.stage.vars.jy) / 2 +
                this.toNumber(this.stage.vars.jspeed);
            }
          }
          if (this.compare(this.stage.vars.jx, 0) > 0) {
            this.stage.vars.playerX +=
              0 -
              (this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            this.x +=
              0 -
              (this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed));
            if (this.touching(this.sprites["Playerdetect"].andClones())) {
              this.stage.vars.scroll = 1;
              this.stage.vars.playerX +=
                this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed);
              this.x +=
                this.toNumber(this.stage.vars.jx) / 2 +
                this.toNumber(this.stage.vars.jspeed);
            }
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveEmergencyMeeting() {
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.stage.vars.playerX = 1550;
      this.stage.vars.playerY = 215;
    } else {
      this.stage.vars.playerX = 1090;
      this.stage.vars.playerY = 1110;
    }
  }

  *whenIReceiveBeginGame2() {
    this.stage.watchers.mobileMode.visible = false;
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.stage.vars.playerX = 1550;
      this.stage.vars.playerY = 215;
    } else {
      this.stage.vars.playerX = 1090;
      this.stage.vars.playerY = 1110;
    }
  }

  *whenIReceiveStopmeeting() {
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.stage.vars.playerX = 1550;
      this.stage.vars.playerY = 215;
    } else {
      this.stage.vars.playerX = 1090;
      this.stage.vars.playerY = 1110;
    }
  }

  *whenIReceiveBeginGame3() {
    while (true) {
      if (this.touching(Color.rgb(129, 128, 63))) {
        this.stage.vars.playerX = 1090;
        this.stage.vars.playerY = 1110;
      }
      yield;
    }
  }
}
