/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Load extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Load/costumes/costume1.svg", {
        x: 257.5,
        y: 192.5,
      }),
    ];

    this.sounds = [new Sound("pop", "./Load/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.effects.ghost = 0;
    while (true) {
      this.moveAhead();
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    this.goto(0, 0);
    this.visible = true;
    this.moveAhead();
    yield* this.wait(1);
    for (let i = 0; i < 10; i++) {
      this.effects.ghost += 10;
      this.moveAhead();
      yield;
    }
    this.visible = false;
  }
}
