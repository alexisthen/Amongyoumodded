/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Vents extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Office 1", "./Vents/costumes/Office 1.svg", {
        x: 3.6001449999999977,
        y: 108.22924,
      }),
      new Costume("Office 2", "./Vents/costumes/Office 2.svg", {
        x: 29.31442499999997,
        y: 28.51495,
      }),
      new Costume("Office 3", "./Vents/costumes/Office 3.svg", {
        x: -23.257004999999992,
        y: 28.086369999999988,
      }),
      new Costume("East Power 1", "./Vents/costumes/East Power 1.svg", {
        x: 87.45728500000001,
        y: 79.6578,
      }),
      new Costume("East Power 2", "./Vents/costumes/East Power 2.svg", {
        x: 127.457275,
        y: 41.08637999999999,
      }),
      new Costume("Kitchen", "./Vents/costumes/Kitchen.svg", {
        x: -73.97130499999997,
        y: -27.485060000000004,
      }),
      new Costume("Repairs 1", "./Vents/costumes/Repairs 1.svg", {
        x: -97.39986499999998,
        y: -58.48505,
      }),
      new Costume("Repairs 2", "./Vents/costumes/Repairs 2.svg", {
        x: -89.11415499999998,
        y: -98.77076000000005,
      }),
      new Costume("Navigation 1", "./Vents/costumes/Navigation 1.svg", {
        x: -31.256995000000018,
        y: -61.34218999999999,
      }),
      new Costume("Navigation 2", "./Vents/costumes/Navigation 2.svg", {
        x: 37.60013500000002,
        y: -61.34219999999999,
      }),
      new Costume("Security", "./Vents/costumes/Security.svg", {
        x: 103.600145,
        y: -58.627910000000014,
      }),
      new Costume("All Vents", "./Vents/costumes/All Vents.svg", {
        x: 127.457285,
        y: 108.22924,
      }),
    ];

    this.sounds = [new Sound("pop", "./Vents/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
    ];

    this.vars.costume = 1;
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.costume = "Office 1";
    } else {
      null;
    }
    this.vars.costume = this.costumeNumber;
    this.costume = "costume1";
    this.size = 800;
    this.costume = this.vars.costume;
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      for (let i = 0; i < 11; i++) {
        this.createClone();
        this.costumeNumber++;
        if (this.costumeNumber === 11) {
          this.createClone();
          this.costumeNumber++;
        }
        yield;
      }
      this.visible = false;
    } else {
      null;
    }
  }

  *startAsClone() {
    while (true) {
      this.goto(
        this.toNumber(this.stage.vars.playerX) +
          this.toNumber(this.stage.vars.mapX),
        this.toNumber(this.stage.vars.playerY) +
          this.toNumber(this.stage.vars.mapY)
      );
      if (this.touching("edge")) {
        this.visible = false;
      } else {
        this.visible = true;
        this.stage.vars.ventnum = this.costumeNumber;
      }
      yield;
    }
  }
}
