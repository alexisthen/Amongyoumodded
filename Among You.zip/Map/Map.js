/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Map extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Map/costumes/costume1.svg", {
        x: 253.5,
        y: 191.199935,
      }),
      new Costume("costume3", "./Map/costumes/costume3.svg", {
        x: 253.5,
        y: 191.199925,
      }),
      new Costume("costume2", "./Map/costumes/costume2.svg", {
        x: 7.611355963289753,
        y: 6.916170279660832,
      }),
    ];

    this.sounds = [new Sound("pop", "./Map/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone4),
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.ghost = 100;
    this.size = 80;
    this.costume = "costume2";
    this.createClone();
    while (true) {
      this.moveAhead();
      this.goto(
        0 -
          (this.toNumber(this.stage.vars.playerX) +
            this.toNumber(this.stage.vars.mapX)) /
            10,
        0 -
          (this.toNumber(this.stage.vars.playerY) +
            this.toNumber(this.stage.vars.mapY)) /
            10
      );
      this.effects.color = this.toNumber(this.stage.vars.color);
      if (this.toNumber(this.stage.vars.maptype) === 2) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }

  *startAsClone() {}

  *whenIReceiveBeginGame() {
    yield* this.wait(1.2);
    this.moveAhead();
  }

  *startAsClone2() {
    this.costume = "costume1";
  }

  *startAsClone3() {
    this.stage.vars.maptype = 1;
    this.effects.ghost = 100;
    this.size = 80;
    this.moveAhead();
    this.goto(0, 0);
    while (true) {
      if (this.toNumber(this.stage.vars.gamemap) === 1) {
        if (this.toNumber(this.stage.vars.maptype) === 1) {
          this.costume = "costume1";
        } else {
          this.costume = "costume3";
        }
      } else {
        if (this.toNumber(this.stage.vars.maptype) === 1) {
          this.costume = "costume1";
        } else {
          this.costume = "costume3";
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {}

  *whenGreenFlagClicked3() {}

  *whenGreenFlagClicked4() {}

  *whenIReceiveDefeat() {
    this.visible = false;
  }

  *whenIReceiveDefeat2() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveEmergencyMeeting() {
    this.stage.vars.showmap = 0;
  }

  *whenIReceiveBeginGame2() {
    while (true) {
      if (this.toNumber(this.stage.vars.showmap) === 1) {
        this.effects.ghost = 0;
      } else {
        this.effects.ghost = 100;
      }
      yield;
    }
  }

  *startAsClone4() {
    while (true) {
      if (this.toNumber(this.stage.vars.showmap) === 1) {
        this.effects.ghost = 0;
      } else {
        this.effects.ghost = 100;
      }
      yield;
    }
  }
}
