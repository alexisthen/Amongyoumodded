/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Inyourface extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Inyourface/costumes/costume1.svg", {
        x: 0,
        y: 0,
      }),
      new Costume("InYourFACE", "./Inyourface/costumes/InYourFACE.svg", {
        x: 269.4954954954955,
        y: 200.8000030517578,
      }),
    ];

    this.sounds = [new Sound("Defeat2", "./Inyourface/sounds/Defeat2.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];
  }

  *whenIReceiveDefeat() {
    this.stage.watchers.mode.visible = false;
    if (this.toNumber(this.stage.vars.votedwrong) === 0) {
      this.stopAllSounds();
      yield* this.startSound("Defeat");
      this.visible = true;
      yield* this.wait(2.8);
      this.visible = false;
    } else {
      null;
    }
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.visible = false;
    while (true) {
      this.moveAhead();
      yield;
    }
  }
}
