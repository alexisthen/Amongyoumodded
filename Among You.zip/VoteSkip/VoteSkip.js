/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class VoteSkip extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Vote", "./VoteSkip/costumes/Vote.svg", {
        x: 64.75,
        y: 20.25,
      }),
      new Costume("Skip", "./VoteSkip/costumes/Skip.svg", {
        x: 64.75,
        y: 20.25,
      }),
    ];

    this.sounds = [
      new Sound("Voted Wrong", "./VoteSkip/sounds/Voted Wrong.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.votedwrong = 0;
    this.size = 80;
    this.costume = "Vote";
    this.goto(-90, -155);
    this.moveAhead();
    this.visible = false;
    this.createClone();
  }

  *startAsClone() {
    this.costume = "Skip";
    this.goto(145, -155);
    this.moveAhead();
  }

  *whenIReceiveEmergencyMeeting() {
    this.visible = true;
    this.moveAhead();
  }

  *whenthisspriteclicked() {
    if (this.costumeNumber === 1) {
      yield* this.decodeVoted();
      this.broadcast("Voted");
      yield* this.wait(6);
      if (
        this.compare(this.stage.vars.votedcolor, this.stage.vars.impostor) === 0
      ) {
        this.broadcast("Victory");
      } else {
        yield* this.startSound("Voted Wrong");
        this.stage.vars.votedwrong = 1;
        this.broadcast("Defeat");
        this.stage.watchers.evidence.visible = false;
      }
    } else {
      yield* this.broadcastAndWait("Skipped");
      this.stage.vars.enemymove = 0;
      this.broadcast("StopMeeting");
    }
  }

  *whenIReceiveStopmeeting() {
    this.visible = false;
  }

  *decodeVoted() {
    if (this.toNumber(this.stage.vars.votedcolor) === 1) {
      this.stage.vars.voted = "Purple";
    } else {
      if (this.toNumber(this.stage.vars.votedcolor) === 2) {
        this.stage.vars.voted = "Pink";
      } else {
        if (this.toNumber(this.stage.vars.votedcolor) === 3) {
          this.stage.vars.voted = "Red";
        } else {
          if (this.toNumber(this.stage.vars.votedcolor) === 4) {
            this.stage.vars.voted = "Orange";
          } else {
            if (this.toNumber(this.stage.vars.votedcolor) === 5) {
              this.stage.vars.voted = "Yellow";
            } else {
              if (this.toNumber(this.stage.vars.votedcolor) === 6) {
                this.stage.vars.voted = "Lime";
              } else {
                if (this.toNumber(this.stage.vars.votedcolor) === 7) {
                  this.stage.vars.voted = "Cyan";
                } else {
                  if (this.toNumber(this.stage.vars.votedcolor) === 8) {
                    this.stage.vars.voted = "Brown";
                  } else {
                    if (this.toNumber(this.stage.vars.votedcolor) === 9) {
                      this.stage.vars.voted = "Blue";
                    } else {
                      if (this.toNumber(this.stage.vars.votedcolor) === 10) {
                        this.stage.vars.voted = "Green";
                      } else {
                        if (this.toNumber(this.stage.vars.votedcolor) === 11) {
                          this.stage.vars.voted = "Black";
                        } else {
                          if (
                            this.toNumber(this.stage.vars.votedcolor) === 12
                          ) {
                            this.stage.vars.voted = "White";
                          } else {
                            null;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
