/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Joystick extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Ball", "./Joystick/costumes/Ball.svg", {
        x: 23.00000000000003,
        y: 23,
      }),
      new Costume("Outside", "./Joystick/costumes/Outside.svg", {
        x: 50,
        y: 49.99999999999994,
      }),
    ];

    this.sounds = [new Sound("pop", "./Joystick/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame3
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.mode.visible = false;
    this.visible = false;
    this.goto(-185, -95);
    this.costume = "Outside";
    this.moveAhead();
    this.createClone();
  }

  *whenIReceiveBeginGame() {
    this.stage.watchers.mode.visible = true;
    if (this.costumeNumber === 2) {
      while (true) {
        this.moveAhead();
        this.stage.vars.jx2 = this.x;
        this.stage.vars.jy2 = this.y;
        yield;
      }
    }
  }

  *startAsClone() {
    this.costume = "Ball";
  }

  *whenIReceiveBeginGame2() {
    while (true) {
      if (!(this.toNumber(this.stage.vars.game) === 0)) {
        if (this.toString(this.stage.vars.mode) === "Mobile Mode") {
          this.stage.watchers.mode.visible = true;
          this.visible = true;
        } else {
          this.visible = false;
        }
      } else {
        this.stage.watchers.mode.visible = false;
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.game = 0;
    while (true) {
      if (this.toNumber(this.stage.vars.mobileMode) === 1) {
        this.stage.vars.mode = "Mobile Mode";
      } else {
        this.stage.vars.mode = "Keyboard Mode";
      }
      yield;
    }
  }

  *whenIReceiveBeginGame3() {
    yield* this.wait(1);
    while (true) {
      if (this.costume.name === "Ball") {
        if (!(this.toNumber(this.stage.vars.game) === 0)) {
          this.moveAhead();
          if (this.mouse.down) {
            this.goto(this.mouse.x, this.mouse.y);
            if (
              this.compare(
                Math.hypot(
                  this.sprites["Joystick"].x - this.x,
                  this.sprites["Joystick"].y - this.y
                ),
                20
              ) > 0
            ) {
              this.goto(-185, -95);
              this.direction = this.radToScratch(
                Math.atan2(this.mouse.y - this.y, this.mouse.x - this.x)
              );
              this.move(22);
            }
            if (this.toNumber(this.stage.vars.move) === 0) {
              this.stage.vars.jx = this.x - this.toNumber(this.stage.vars.jx2);
              this.stage.vars.jy = this.y - this.toNumber(this.stage.vars.jy2);
            }
          } else {
            this.goto(-185, -95);
            if (this.toNumber(this.stage.vars.move) === 0) {
              this.stage.vars.jx = this.x - this.toNumber(this.stage.vars.jx2);
              this.stage.vars.jy = this.y - this.toNumber(this.stage.vars.jy2);
            }
          }
        } else {
          this.goto(-185, -95);
          this.stage.vars.jx = 0;
          this.stage.vars.jy = 0;
        }
      }
      if (this.toNumber(this.stage.vars.joystick) === 0) {
        this.goto(-185, -95);
        this.stage.vars.jx = 0;
        this.stage.vars.jy = 0;
      }
      yield;
    }
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveDefeat2() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
