/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class MapSensor extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Office", "./MapSensor/costumes/Office.png", {
        x: 120,
        y: 253,
      }),
      new Costume("East Power", "./MapSensor/costumes/East Power.png", {
        x: 262,
        y: 178,
      }),
      new Costume("West Power", "./MapSensor/costumes/West Power.png", {
        x: -156,
        y: 178,
      }),
      new Costume("Report", "./MapSensor/costumes/Report.png", {
        x: 438,
        y: -13,
      }),
      new Costume("Kitchen", "./MapSensor/costumes/Kitchen.png", {
        x: -108,
        y: 40,
      }),
      new Costume("Repairs", "./MapSensor/costumes/Repairs.png", {
        x: -168,
        y: -95,
      }),
      new Costume("Storage", "./MapSensor/costumes/Storage.png", {
        x: -348,
        y: 150,
      }),
      new Costume("Navigation", "./MapSensor/costumes/Navigation.png", {
        x: 84,
        y: -59,
      }),
      new Costume("Security", "./MapSensor/costumes/Security.png", {
        x: 271,
        y: -97,
      }),
      new Costume("costume3", "./MapSensor/costumes/costume3.png", {
        x: 0,
        y: 0,
      }),
      new Costume("costume5", "./MapSensor/costumes/costume5.png", {
        x: 1,
        y: 1,
      }),
      new Costume("costume4", "./MapSensor/costumes/costume4.png", {
        x: 438,
        y: 253,
      }),
      new Costume("costume2", "./MapSensor/costumes/costume2.svg", {
        x: 219,
        y: 126.5,
      }),
    ];

    this.sounds = [new Sound("pop", "./MapSensor/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "LightsOn" },
        this.whenIReceiveLightson
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
    ];

    this.vars.clonenum = 9;
    this.vars.costume = 10;
  }

  *whenGreenFlagClicked() {
    this.vars.clonenum = 0;
    this.visible = true;
    this.goto(0, 0);
    this.effects.ghost = 100;
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.costume = "Office";
      for (let i = 0; i < 9; i++) {
        this.vars.clonenum++;
        this.createClone();
        this.costumeNumber++;
        yield;
      }
    } else {
      null;
    }
    this.visible = false;
  }

  *startAsClone() {
    while (true) {
      this.effects.ghost = 100;
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        if (this.compare(this.vars.clonenum, this.stage.vars.lightnum) === 0) {
          this.stage.vars.lights = 1;
        } else {
          this.stage.vars.lights = 0;
        }
      }
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    this.stage.vars.lightscooldown = 0;
  }

  *startAsClone2() {
    while (true) {
      null;
      yield;
    }
  }

  *whenIReceiveLightson() {}

  *whenIReceiveBeginGame2() {
    this.costume = "Skeld";
    this.vars.costume = this.costumeNumber;
    this.costume = "costume5";
    this.size = 800;
    this.costume = this.vars.costume;
    while (true) {
      this.goto(this.sprites["Walls"].x, this.sprites["Walls"].y);
      yield;
    }
  }

  *startAsClone3() {
    if (this.costume.name === "Report") {
      while (true) {
        if (this.touching(this.sprites["Playerdetect"].andClones())) {
          this.stage.vars.safe = 1;
        } else {
          this.stage.vars.safe = 0;
        }
        yield;
      }
    }
  }
}
