/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("backdrop1", "./Stage/costumes/backdrop1.svg", {
        x: 240,
        y: 180,
      }),
      new Costume("Blue Sky 2 ", "./Stage/costumes/Blue Sky 2 .svg", {
        x: 240,
        y: 180,
      }),
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [];

    this.vars.voted = "Red";
    this.vars.game = 0;
    this.vars.mode = "Keyboard Mode";
    this.vars.aVariable = 0;
    this.vars.mobileMode = 0;
    this.vars.mobile = "OFF";
    this.vars.votedwrong = 0;
    this.vars.enemymove = 0;
    this.vars.votedcolor = 1;
    this.vars.impostor = 1;
    this.vars.use = 0;
    this.vars.move = 0;
    this.vars.timer = 0.99;
    this.vars.time = "00 : 00 : 00";
    this.vars.scans = "0 / 17";
    this.vars.ventnum = 0;
    this.vars.gamemap = 1;
    this.vars.playerX = 1550;
    this.vars.mapX = 0;
    this.vars.playerY = 215;
    this.vars.mapY = 0;
    this.vars.scanChecker = "false";
    this.vars.report = 0;
    this.vars.player = 10;
    this.vars.searching = 0;
    this.vars.cluecheck = 0;
    this.vars.clue = 0;
    this.vars.safe = 0;
    this.vars.touch = "false";
    this.vars.maptype = 1;
    this.vars.showmap = 0;
    this.vars.color = -60;
    this.vars.joystick = 1;
    this.vars.lights = 0;
    this.vars.touchingmap = 0;
    this.vars.lightsstay = 0;
    this.vars.lightnum = 0;
    this.vars.lightscooldown = 0;
    this.vars.roomnum = 0;
    this.vars.cluecolor = "Cyan";
    this.vars.impostorNumber = 1;
    this.vars.dead = 6;
    this.vars.cluecolornum = 4;
    this.vars.jx = 0;
    this.vars.jy = 0;
    this.vars.jx2 = -185;
    this.vars.jy2 = -95;
    this.vars.checking = 0;
    this.vars.teleport = 4;
    this.vars.scanscompleted = 0;
    this.vars.scanning = 0;
    this.vars.scancount = 0;
    this.vars.meetingdesign = 0;
    this.vars.seconds = 0;
    this.vars.minutes = 0;
    this.vars.hours = 0;
    this.vars.scroll = 0;
    this.vars.jspeed = 0;
    this.vars.playerspeed = 50;
    this.vars.enemyX = -18.388052984772635;
    this.vars.enemyy = 27.690175539153323;
    this.vars.vent = 0;
    this.vars.antiKill = 0;
    this.vars.winonlose = 0;
    this.vars.evidence = [];
    this.vars.deadplayers = [];
    this.vars.players = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
    this.vars.ventX = [];
    this.vars.ventY = [];

    this.watchers.voted = new Watcher({
      label: "Voted",
      style: "normal",
      visible: false,
      value: () => this.vars.voted,
      x: 245,
      y: 149,
    });
    this.watchers.mode = new Watcher({
      label: "Mode",
      style: "normal",
      visible: false,
      value: () => this.vars.mode,
      x: 362,
      y: 179,
    });
    this.watchers.mobileMode = new Watcher({
      label: "MOBILE MODE",
      style: "large",
      visible: false,
      value: () => this.vars.mobileMode,
      x: 245,
      y: 175,
    });
    this.watchers.mobile = new Watcher({
      label: "MOBILE?",
      style: "large",
      visible: false,
      value: () => this.vars.mobile,
      x: 245,
      y: 176,
    });
    this.watchers.enemymove = new Watcher({
      label: "EnemyMove",
      style: "normal",
      visible: false,
      value: () => this.vars.enemymove,
      x: 573,
      y: 35,
    });
    this.watchers.time = new Watcher({
      label: "Time",
      style: "large",
      visible: false,
      value: () => this.vars.time,
      x: 440,
      y: 91,
    });
    this.watchers.scans = new Watcher({
      label: "Scans",
      style: "normal",
      visible: false,
      value: () => this.vars.scans,
      x: 244,
      y: 136,
    });
    this.watchers.playerX = new Watcher({
      label: "Player X",
      style: "normal",
      visible: false,
      value: () => this.vars.playerX,
      x: 574,
      y: 149,
    });
    this.watchers.playerY = new Watcher({
      label: "Player Y",
      style: "normal",
      visible: false,
      value: () => this.vars.playerY,
      x: 578,
      y: 127,
    });
    this.watchers.playerspeed = new Watcher({
      label: "PlayerSpeed",
      style: "normal",
      visible: false,
      value: () => this.vars.playerspeed,
      x: 575,
      y: 171,
    });
    this.watchers.enemyX = new Watcher({
      label: "Enemy X",
      style: "normal",
      visible: false,
      value: () => this.vars.enemyX,
      x: 574,
      y: 69,
    });
    this.watchers.enemyy = new Watcher({
      label: "EnemyY",
      style: "normal",
      visible: false,
      value: () => this.vars.enemyy,
      x: 576,
      y: 91,
    });
    this.watchers.evidence = new Watcher({
      label: "Evidence",
      style: "normal",
      visible: false,
      value: () => this.vars.evidence,
      x: 524,
      y: 55,
      width: 196,
      height: 145,
    });
    this.watchers.deadplayers = new Watcher({
      label: "DeadPlayers",
      style: "normal",
      visible: false,
      value: () => this.vars.deadplayers,
      x: 245,
      y: 175,
      width: undefined,
      height: undefined,
    });
  }
}
