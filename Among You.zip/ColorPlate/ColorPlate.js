/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ColorPlate extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./ColorPlate/costumes/costume1.png", {
        x: 480,
        y: 360,
      }),
      new Costume("costume2", "./ColorPlate/costumes/costume2.png", {
        x: 480,
        y: 360,
      }),
    ];

    this.sounds = [new Sound("pop", "./ColorPlate/sounds/pop.wav")];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickColor" },
        this.whenIReceivePickcolor
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickMap" },
        this.whenIReceivePickmap
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
    ];
  }

  *whenIReceivePickcolor() {
    this.visible = true;
    for (let i = 0; i < 3; i++) {
      this.moveAhead(1);
      this.moveAhead(1);
      yield;
    }
  }

  *whenGreenFlagClicked() {
    yield* this.wait(1);
    this.costume = "costume1";
    this.visible = false;
  }

  *whenIReceivePickmap() {
    this.moveAhead();
    this.moveBehind(2);
  }

  *whenIReceiveShowRole() {
    this.visible = false;
  }
}
