/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class HatVisor extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Standing", "./HatVisor/costumes/Standing.svg", {
        x: 55.113685000000004,
        y: 86.552225,
      }),
      new Costume("Walking 1", "./HatVisor/costumes/Walking 1.svg", {
        x: 55.113685000000004,
        y: 100.552225,
      }),
      new Costume("Walking 2", "./HatVisor/costumes/Walking 2.svg", {
        x: 55.113685000000004,
        y: 105.552225,
      }),
      new Costume("Walking 3", "./HatVisor/costumes/Walking 3.svg", {
        x: 55.113685000000004,
        y: 100.552225,
      }),
      new Costume("Walking 4", "./HatVisor/costumes/Walking 4.svg", {
        x: 55.113685000000004,
        y: 86.552225,
      }),
      new Costume("Walking 5", "./HatVisor/costumes/Walking 5.svg", {
        x: 55.113685000000004,
        y: 100.552225,
      }),
      new Costume("Walking 6", "./HatVisor/costumes/Walking 6.svg", {
        x: 54.113685000000004,
        y: 104.552225,
      }),
      new Costume("Walking 7", "./HatVisor/costumes/Walking 7.svg", {
        x: 55.113685000000004,
        y: 100.552225,
      }),
      new Costume("Walking 8", "./HatVisor/costumes/Walking 8.svg", {
        x: 55.113685000000004,
        y: 86.552225,
      }),
      new Costume("Dead 1", "./HatVisor/costumes/Dead 1.svg", {
        x: 40.41749500000003,
        y: 26.72544032686463,
      }),
      new Costume("Dead 2", "./HatVisor/costumes/Dead 2.svg", {
        x: 49.3362042857143,
        y: 4.776312160461657,
      }),
      new Costume("Ghost 1", "./HatVisor/costumes/Ghost 1.svg", {
        x: 54.63088930232561,
        y: 54.34554,
      }),
      new Costume("Ghost 2", "./HatVisor/costumes/Ghost 2.svg", {
        x: 56.63088930232573,
        y: 54.34554,
      }),
      new Costume("Ghost 3", "./HatVisor/costumes/Ghost 3.svg", {
        x: 56.63089000000011,
        y: 54.34554,
      }),
      new Costume("Among You Hat", "./HatVisor/costumes/Among You Hat.svg", {
        x: 41.30478306818185,
        y: 18.662400546345737,
      }),
    ];

    this.sounds = [
      new Sound("Footsteps", "./HatVisor/sounds/Footsteps.wav"),
      new Sound("Footsteps2", "./HatVisor/sounds/Footsteps2.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame3
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame4
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame5
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickColor" },
        this.whenIReceivePickcolor
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickColor" },
        this.whenIReceivePickcolor2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame6
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame7
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Victory" },
        this.whenIReceiveVictory
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "Standing";
    this.visible = false;
    while (true) {
      if (this.toNumber(this.stage.vars.move) === 1) {
        this.costume = "Standing";
      }
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
    this.moveAhead();
    while (true) {
      this.goto(this.sprites["Playerdetect"].x, this.sprites["Playerdetect"].y);
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.direction = 90;
    this.costume = "Standing";
  }

  *whenIReceiveBeginGame2() {
    this.size = 40;
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Keyboard Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (
            this.keyPressed("up arrow") ||
            this.keyPressed("down arrow") ||
            this.keyPressed("w") ||
            this.keyPressed("s") ||
            this.keyPressed("d") ||
            this.keyPressed("a") ||
            this.keyPressed("left arrow") ||
            this.keyPressed("right arrow")
          ) {
            this.costume = "Walking 1";
            yield* this.wait(0.06);
            this.costume = "Walking 2";
            yield* this.wait(0.06);
            this.costume = "Walking 3";
            yield* this.wait(0.06);
            this.costume = "Walking 4";
            yield* this.wait(0.06);
            if (
              this.keyPressed("up arrow") ||
              this.keyPressed("down arrow") ||
              this.keyPressed("w") ||
              this.keyPressed("s") ||
              this.keyPressed("d") ||
              this.keyPressed("a") ||
              this.keyPressed("left arrow") ||
              this.keyPressed("right arrow")
            ) {
              this.costume = "Walking 5";
              yield* this.wait(0.06);
              this.costume = "Walking 6";
              yield* this.wait(0.06);
              this.costume = "Walking 7";
              yield* this.wait(0.06);
              this.costume = "Walking 8";
              yield* this.wait(0.06);
            }
          } else {
            this.costume = "Standing";
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveBeginGame3() {
    this.direction = 90;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Mobile Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (this.compare(this.stage.vars.jx, 0) < 0) {
            this.direction = -90;
          } else {
            if (this.compare(this.stage.vars.jx, 0) > 0) {
              this.direction = 90;
            } else {
              this.costume = "Standing";
            }
          }
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Mobile Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (
            !(this.toNumber(this.stage.vars.jx) === 0) ||
            !(this.toNumber(this.stage.vars.jy) === 0)
          ) {
            this.costume = "Walking 1";
            yield* this.wait(0.06);
            this.costume = "Walking 2";
            yield* this.wait(0.06);
            this.costume = "Walking 3";
            yield* this.wait(0.06);
            this.costume = "Walking 4";
            yield* this.wait(0.06);
            if (
              !(this.toNumber(this.stage.vars.jx) === 0) ||
              !(this.toNumber(this.stage.vars.jy) === 0)
            ) {
              this.costume = "Walking 5";
              yield* this.wait(0.06);
              this.costume = "Walking 6";
              yield* this.wait(0.06);
              this.costume = "Walking 7";
              yield* this.wait(0.06);
              this.costume = "Walking 8";
              yield* this.wait(0.06);
            }
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveShowRole() {
    this.goto(0, -50);
    this.size = 70;
    this.visible = true;
    this.moveAhead();
    yield* this.wait(0.1);
    this.moveAhead();
  }

  *whenIReceiveShowRole2() {
    this.visible = false;
    this.effects.brightness = -100;
    yield* this.wait(1);
    this.visible = true;
    for (let i = 0; i < 34; i++) {
      this.effects.brightness += 3;
      yield;
    }
    yield* this.wait(3);
    for (let i = 0; i < 34; i++) {
      this.effects.brightness -= 3;
      yield;
    }
    this.moveBehind();
    this.effects.clear();
  }

  *whenIReceiveBeginGame4() {
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Keyboard Mode") {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (this.keyPressed("a") || this.keyPressed("left arrow")) {
            this.direction = -90;
          }
          if (this.keyPressed("right arrow") || this.keyPressed("d")) {
            this.direction = 90;
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveBeginGame5() {
    yield* this.wait(0.05);
    this.moveAhead();
  }

  *whenIReceivePickcolor() {
    yield* this.wait(0.2);
    this.moveAhead();
  }

  *whenIReceivePickcolor2() {
    this.goto(-100, 0);
    this.size = 200;
    this.moveAhead();
    for (let i = 0; i < 10; i++) {
      this.moveAhead();
      this.visible = true;
      yield;
    }
    this.visible = true;
  }

  *whenIReceiveBeginGame6() {
    this.visible = false;
    this.stage.vars.lights = 0;
    yield* this.wait(0.5);
    this.visible = true;
  }

  *whenIReceiveBeginGame7() {
    this.visible = false;
    this.stage.vars.lights = 0;
    yield* this.wait(0.5);
    this.visible = true;
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveVictory() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.costume = "Standing";
    this.goto(0, -50);
    this.size = 80;
    this.visible = true;
    this.direction = 90;
    this.moveAhead();
    while (true) {
      this.moveAhead();
      yield;
    }
  }

  *whenIReceiveStopmeeting() {
    this.direction = 90;
  }

  *whenIReceiveDefeat2() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
