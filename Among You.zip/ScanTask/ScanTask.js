/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class ScanTask extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Base", "./ScanTask/costumes/Base.svg", {
        x: 160.40385,
        y: 159.5,
      }),
      new Costume("Scan", "./ScanTask/costumes/Scan.svg", {
        x: 108.48075499999999,
        y: 144.59998000000002,
      }),
      new Costume("Scanning", "./ScanTask/costumes/Scanning.svg", {
        x: 99.73979659571944,
        y: 144.59999499999998,
      }),
      new Costume("Scan2", "./ScanTask/costumes/Scan2.svg", {
        x: 92.9903633673469,
        y: 86.027775,
      }),
    ];

    this.sounds = [
      new Sound("A Bass", "./ScanTask/sounds/A Bass.wav"),
      new Sound("A Bass2", "./ScanTask/sounds/A Bass2.wav"),
      new Sound("A Bass4", "./ScanTask/sounds/A Bass4.wav"),
      new Sound("A Bass3", "./ScanTask/sounds/A Bass3.wav"),
      new Sound("A Bass5", "./ScanTask/sounds/A Bass5.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.BROADCAST, { name: "Scan" }, this.whenIReceiveScan),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopScan" },
        this.whenIReceiveStopscan
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Victory" },
        this.whenIReceiveVictory
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.scanChecker = "false";
    this.goto(0, 0);
    this.visible = false;
    this.costume = "Base";
    this.createClone();
    this.stage.vars.scanscompleted = 0;
    this.stage.vars.scanning = 0;
  }

  *startAsClone() {
    this.costume = "Scan";
    while (!(this.toNumber(this.stage.vars.game) === 1)) {
      yield;
    }
    while (true) {
      this.moveAhead();
      if (this.toNumber(this.stage.vars.scanning) === 1) {
        if (this.mouse.down && this.touching("mouse")) {
          this.stage.vars.scancount++;
          this.costume = "Scanning";
        } else {
          this.stage.vars.scancount = 0;
          this.costume = "Scan";
        }
      }
      if (this.compare(this.stage.vars.scancount, 75) > 0) {
        this.stage.vars.scanChecker = "true";
        this.stage.vars.scanscompleted++;
        this.stage.vars.scancount = 0;
        this.broadcast("StopScan");
        this.visible = false;
        this.broadcast("ClueFound");
        yield* this.wait(0.5);
        this.stage.vars.scanChecker = "false";
      }
      if (this.toNumber(this.stage.vars.scanning) === 0) {
        this.visible = false;
      }
      yield;
    }
  }

  *whenIReceiveScan() {
    this.stage.vars.scanning = 1;
    this.stage.vars.move = 1;
    this.moveAhead();
    this.visible = true;
  }

  *whenIReceiveStopscan() {
    this.stage.vars.scanning = 0;
    this.stage.vars.move = 0;
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    while (!(this.toNumber(this.stage.vars.scanscompleted) === 17)) {
      yield;
    }
    this.stage.vars.game = 0;
    yield* this.wait(1);
    this.broadcast("Victory");
  }

  *whenIReceiveDefeat() {
    this.stage.watchers.scans.visible = false;
    this.stage.vars.move = 1;
    this.visible = false;
  }

  *whenGreenFlagClicked3() {
    this.stage.watchers.scans.visible = false;
    while (true) {
      this.stage.vars.scans =
        this.toString(this.stage.vars.scanscompleted) + " / 17";
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    this.stage.watchers.scans.visible = true;
  }

  *whenIReceiveVictory() {
    this.stage.watchers.scans.visible = false;
  }

  *startAsClone2() {
    this.costume = "Scan";
    while (!(this.toNumber(this.stage.vars.game) === 1)) {
      yield;
    }
    while (true) {
      if (this.toNumber(this.stage.vars.scanning) === 1) {
        if (this.mouse.down && this.touching("mouse")) {
          yield* this.playSoundUntilDone("A Bass3");
        }
      }
      yield;
    }
  }

  *whenIReceiveBeginGame2() {
    this.stage.vars.showmap = 0;
    this.stage.vars.maptype = 0;
    this.stage.vars.scanning = 0;
    this.stage.vars.move = 0;
    this.visible = false;
  }
}
