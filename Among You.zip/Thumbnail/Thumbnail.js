/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Thumbnail extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "b8f4b-16036910664035-800",
        "./Thumbnail/costumes/b8f4b-16036910664035-800.svg",
        { x: 313.7614678899083, y: 182.17855072021487 }
      ),
    ];

    this.sounds = [new Sound("pop", "./Thumbnail/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.TIMER_GREATER_THAN,
        { VALUE: () => this.stage.vars.timer },
        this.whengreaterthan
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "costume1";
    this.visible = false;
    this.restartTimer();
    this.goto(0, 0);
    while (true) {
      this.stage.vars.timer = this.timer;
      yield;
    }
  }

  *whengreaterthan() {
    this.moveAhead();
    this.stage.watchers.evidence.visible = false;
    this.visible = true;
    this.stage.watchers.time.visible = false;
    this.stage.watchers.mobileMode.visible = false;
    this.stage.watchers.mode.visible = false;
    this.stage.watchers.mobile.visible = false;
    this.stage.watchers.scans.visible = false;
  }
}
