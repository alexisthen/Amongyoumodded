/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class WallCover extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./WallCover/costumes/costume1.svg", {
        x: 0.5,
        y: -0.5,
      }),
      new Costume("Map1", "./WallCover/costumes/Map1.svg", {
        x: 254.521645,
        y: 179.31666,
      }),
      new Costume("Map2", "./WallCover/costumes/Map2.svg", {
        x: 170.063285,
        y: 139.11994923862144,
      }),
      new Costume("Map3", "./WallCover/costumes/Map3.svg", {
        x: 170.06329499999998,
        y: 139.11994923862144,
      }),
    ];

    this.sounds = [new Sound("pop", "./WallCover/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
    while (true) {
      this.goto(this.sprites["Walls"].x, this.sprites["Walls"].y);
      yield;
    }
  }

  *whenIReceiveBeginGame2() {
    yield* this.wait(0.1);
    this.moveAhead();
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.effects.ghost = 0;
      this.costume = "Map1";
    } else {
      this.effects.ghost = 30;
      this.costume = "Map2";
    }
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
