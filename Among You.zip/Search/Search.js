/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Search extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Search/costumes/costume1.svg", {
        x: 63.60609541758197,
        y: 58.57181000000003,
      }),
      new Costume("costume", "./Search/costumes/costume.svg", {
        x: 95.53695150563661,
        y: -28.318944999999985,
      }),
      new Costume("costume2", "./Search/costumes/costume2.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [new Sound("Clue", "./Search/sounds/Clue.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.move = 0;
    this.costume = "costume1";
    this.goto(-78, -108);
    this.size = 80;
    this.visible = false;
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
    yield* this.wait(0.35);
    this.moveAhead();
  }

  *whenGreenFlagClicked2() {
    this.createClone();
    while (true) {
      if (this.toNumber(this.stage.vars.game) === 1) {
        this.moveAhead();
        if (this.toNumber(this.stage.vars.clue) === 1) {
          this.effects.brightness = 20;
        } else {
          this.effects.brightness = -10;
        }
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.toNumber(this.stage.vars.clue) === 1) {
      this.stage.vars.searching = 1;
      this.stage.vars.cluecheck = 1;
      this.stage.vars.move = 1;
      yield* this.wait(this.random(2.5, 4));
      this.stage.vars.cluecheck = 0;
      this.stage.vars.move = 0;
      this.stage.vars.clue = 0;
      if (this.toNumber(this.stage.vars.searching) === 1) {
        this.broadcast("ClueFound");
        this.stage.vars.searching = 0;
        yield* this.startSound("Clue");
      }
    }
  }

  *startAsClone() {
    this.goto(0, 0);
    this.costume = "costume";
    while (true) {
      if (this.toNumber(this.stage.vars.game) === 1) {
        this.moveAhead();
      }
      if (this.toNumber(this.stage.vars.move) === 1) {
        if (this.toString(this.stage.vars.touch) === "false") {
          this.visible = true;
        }
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenIReceiveEmergencyMeeting() {
    this.stage.vars.playerX = 1550;
    this.stage.vars.playerY = 215;
    this.stage.vars.move = 2;
    this.stage.vars.safe = 1;
    this.stage.vars.cluecheck = 0;
    this.visible = false;
  }

  *whenIReceiveStopmeeting() {
    this.visible = true;
  }

  *whenthisspriteclicked2() {}

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toString(this.stage.vars.mode) === "Keyboard Mode") {
        this.goto(-158, -108);
      } else {
        this.goto(-78, -108);
      }
      yield;
    }
  }
}
