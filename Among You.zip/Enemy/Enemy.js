/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Enemy extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Standing", "./Enemy/costumes/Standing.svg", {
        x: 40.084172739427544,
        y: 54.345544534559295,
      }),
      new Costume("Walking 1", "./Enemy/costumes/Walking 1.svg", {
        x: 47.80838246440413,
        y: 66.35382500000001,
      }),
      new Costume("Walking 2", "./Enemy/costumes/Walking 2.svg", {
        x: 47.80838246440405,
        y: 65.41430500000001,
      }),
      new Costume("Walking 3", "./Enemy/costumes/Walking 3.svg", {
        x: 47.80838746440409,
        y: 61.41429499999998,
      }),
      new Costume("Walking 4", "./Enemy/costumes/Walking 4.svg", {
        x: 40.08414500000015,
        y: 49.89407500000004,
      }),
      new Costume("Walking 5", "./Enemy/costumes/Walking 5.svg", {
        x: 47.808387464404035,
        y: 61.586684999999974,
      }),
      new Costume("Walking 6", "./Enemy/costumes/Walking 6.svg", {
        x: 47.808389928808026,
        y: 67.22492044199885,
      }),
      new Costume("Walking 7", "./Enemy/costumes/Walking 7.svg", {
        x: 47.808387464404035,
        y: 61.586684999999974,
      }),
      new Costume("Walking 8", "./Enemy/costumes/Walking 8.svg", {
        x: 40.08415123220209,
        y: 49.89408500000002,
      }),
      new Costume("Vent 1", "./Enemy/costumes/Vent 1.svg", {
        x: 47.71684166666665,
        y: 81.85257811906325,
      }),
      new Costume("Vent 2", "./Enemy/costumes/Vent 2.svg", {
        x: 47.71682999999999,
        y: 81.85257999999999,
      }),
      new Costume("Vent 3", "./Enemy/costumes/Vent 3.svg", {
        x: 47.71682999999999,
        y: 81.85257999999999,
      }),
      new Costume("Vent 4", "./Enemy/costumes/Vent 4.svg", {
        x: 47.71682999999999,
        y: 81.85257999999999,
      }),
    ];

    this.sounds = [
      new Sound("pop", "./Enemy/sounds/pop.wav"),
      new Sound("Vent 2", "./Enemy/sounds/Vent 2.wav"),
      new Sound("Vent 1", "./Enemy/sounds/Vent 1.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame3
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame4
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked7),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "enemy solara" },
        this.whenIReceiveEnemySolara
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "kill enemy" },
        this.whenIReceiveKillEnemy
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "fix enemy" },
        this.whenIReceiveFixEnemy
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "fix enemy" },
        this.whenIReceiveFixEnemy2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked8),
    ];

    this.vars.dir = 61.17874076211887;
    this.vars.skirt = 0;
    this.vars.try = 64;
    this.vars.temp = -12;
    this.vars.sd = 3.6020178330973844;
  }

  *turnAway(distance) {
    this.move(this.toNumber(distance));
    if (
      !(
        this.touching(this.sprites["Walls"].andClones()) ||
        this.touching(this.sprites["Enemy"].andClones())
      )
    ) {
      return;
    }
    this.vars.temp = 0 - this.toNumber(distance);
    this.move(this.toNumber(this.vars.temp));
    this.vars.try = 1;
    for (let i = 0; i < 32; i++) {
      this.direction =
        this.toNumber(this.vars.dir) + this.toNumber(this.vars.try);
      this.move(this.toNumber(distance));
      if (
        !(
          this.touching(this.sprites["Walls"].andClones()) ||
          this.touching(this.sprites["Enemy"].andClones())
        )
      ) {
        this.vars.sd += this.toNumber(this.vars.try) / 2;
        return;
      }
      this.move(this.toNumber(this.vars.temp));
      this.direction =
        this.toNumber(this.vars.dir) - this.toNumber(this.vars.try);
      this.move(this.toNumber(distance));
      if (
        !(
          this.touching(this.sprites["Walls"].andClones()) ||
          this.touching(this.sprites["Enemy"].andClones())
        )
      ) {
        this.vars.sd += this.toNumber(this.vars.try) / -2;
        return;
      }
      this.move(this.toNumber(this.vars.temp));
      this.vars.try = this.toNumber(this.vars.try) * 2;
    }
    this.vars.try = "";
    this.direction = this.toNumber(this.vars.dir);
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveBeginGame() {
    this.size = 43;
    this.moveAhead();
    this.direction = 0;
    this.goto(0, 0);
    this.vars.skirt = "";
    this.vars.sd = 0;
    this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
    while (true) {
      if (this.toNumber(this.stage.vars.vent) === 0) {
        this.vars.dir = this.direction;
        this.direction = this.radToScratch(
          Math.atan2(
            this.sprites["Player"].y - this.y,
            this.sprites["Player"].x - this.x
          )
        );
        this.vars.sd +=
          (((this.direction - this.toNumber(this.vars.dir) + 180) % 360) -
            180) *
          0.05;
        this.vars.sd = this.toNumber(this.vars.sd) * 0.7;
        this.vars.dir += this.toNumber(this.vars.sd);
        this.direction = this.toNumber(this.vars.dir);
        yield* this.turnAway(12);
        if (this.compare(this.vars.try, "") > 0) {
          this.move(-6);
        }
        this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
      }
      yield;
    }
  }

  *whenIReceiveBeginGame2() {
    this.stage.vars.enemyX = -1300;
    this.stage.vars.enemyy = -285;
    this.visible = false;
    while (true) {
      if (this.toNumber(this.stage.vars.vent) === 1) {
        this.goto(
          this.toNumber(this.stage.vars.playerX) -
            this.toNumber(
              this.itemOf(this.stage.vars.ventX, this.stage.vars.ventnum - 1)
            ) +
            this.toNumber(this.stage.vars.mapX),
          this.toNumber(this.stage.vars.playerY) -
            this.toNumber(
              this.itemOf(this.stage.vars.ventY, this.stage.vars.ventnum - 1)
            ) +
            this.toNumber(this.stage.vars.mapY)
        );
      }
      if (this.toNumber(this.stage.vars.scroll) === 0) {
        if (this.toNumber(this.stage.vars.move) === 0) {
          if (this.toString(this.stage.vars.mode) === "Keyboard Mode") {
            if (this.keyPressed("w") || this.keyPressed("up arrow")) {
              this.y -= 6;
              if (this.touching(this.sprites["Walls"].andClones())) {
                this.y -= 10;
              }
            }
            if (this.keyPressed("s") || this.keyPressed("down arrow")) {
              this.y += 6;
              if (this.touching(this.sprites["Walls"].andClones())) {
                this.y += 10;
              }
            }
            if (this.keyPressed("right arrow") || this.keyPressed("d")) {
              this.x -= 6;
              if (this.touching(this.sprites["Walls"].andClones())) {
                this.x -= 10;
              }
            }
            if (this.keyPressed("a") || this.keyPressed("left arrow")) {
              this.x += 6;
              if (this.touching(this.sprites["Walls"].andClones())) {
                this.x += 10;
              }
            }
          } else {
            this.x += 0 - this.toNumber(this.stage.vars.jx) / 2;
            this.y += 0 - this.toNumber(this.stage.vars.jy) / 2;
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveBeginGame3() {}

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toNumber(this.stage.vars.vent) === 0) {
        this.costume = "Walking 1";
        yield* this.wait(0.03);
        if (this.toNumber(this.stage.vars.vent) === 0) {
          this.costume = "Walking 5";
          yield* this.wait(0.03);
          if (this.toNumber(this.stage.vars.vent) === 0) {
            this.costume = "Walking 6";
            yield* this.wait(0.03);
            if (this.toNumber(this.stage.vars.vent) === 0) {
              this.costume = "Walking 2";
              yield* this.wait(0.03);
              if (this.toNumber(this.stage.vars.vent) === 0) {
                this.costume = "Walking 3";
                yield* this.wait(0.03);
                if (this.toNumber(this.stage.vars.vent) === 0) {
                  this.costume = "Walking 7";
                  yield* this.wait(0.03);
                  if (this.toNumber(this.stage.vars.vent) === 0) {
                    this.costume = "Walking 8";
                    yield* this.wait(0.03);
                    if (this.toNumber(this.stage.vars.vent) === 0) {
                      this.costume = "Walking 4";
                      yield* this.wait(0.03);
                    }
                  }
                }
              }
            }
          }
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      while (!this.touching(this.sprites["Playerdetect"].andClones())) {
        yield;
      }
      yield* this.wait(0.5);
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        if (
          this.toNumber(this.stage.vars.vent) === 0 &&
          this.toNumber(this.stage.vars.antiKill) === 0
        ) {
          this.stage.vars.votedwrong = 0;
          this.broadcast("Defeat");
          /* TODO: Implement stop other scripts in sprite */ null;
          this.visible = false;
        }
      }
      while (!!this.touching(this.sprites["Playerdetect"].andClones())) {
        yield;
      }
      yield;
    }
  }

  *whenIReceiveBeginGame4() {
    this.stage.vars.vent = 0;
    yield* this.wait(this.random(4, 5));
    while (true) {
      if (this.toNumber(this.stage.vars.enemymove) === 0) {
        this.visible = false;
        yield* this.wait(this.random(3, 4));
        yield* this.startSound("Vent 2");
        yield* this.wait(this.random(3, 4));
        if (this.toNumber(this.stage.vars.lights) === 0) {
          if (this.toNumber(this.stage.vars.safe) === 0) {
            if (!(this.toNumber(this.stage.vars.ventnum) === 0)) {
              this.goto(
                this.toNumber(this.stage.vars.playerX) -
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.ventX,
                      this.stage.vars.ventnum - 1
                    )
                  ) +
                  this.toNumber(this.stage.vars.mapX),
                this.toNumber(this.stage.vars.playerY) -
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.ventY,
                      this.stage.vars.ventnum - 1
                    )
                  ) +
                  this.toNumber(this.stage.vars.mapY)
              );
              yield* this.startSound("Vent 1");
              this.direction = 90;
              this.stage.vars.vent = 1;
              this.costume = "Vent 1";
              this.visible = true;
              this.costume = "Vent 1";
              for (let i = 0; i < 3; i++) {
                yield* this.wait(0.04);
                this.costumeNumber++;
                yield;
              }
              yield* this.wait(0.04);
              this.costume = "Standing";
              yield* this.wait(0.1);
              this.stage.vars.vent = 0;
              yield* this.chase();
            }
          }
        }
      }
      yield;
    }
  }

  *chase() {
    yield* this.wait(this.random(3, 8));
    if (
      !this.touching(this.sprites["EnemySensor"].andClones()) &&
      this.toNumber(this.stage.vars.lights) === 0
    ) {
      this.visible = false;
    } else {
      yield* this.chase();
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toNumber(this.stage.vars.lights) === 1) {
        if (this.touching("edge")) {
          this.visible = false;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    this.stage.vars.enemymove = 0;
  }

  *whenIReceiveEmergencyMeeting() {
    this.stage.vars.enemymove = 1;
    this.visible = false;
  }

  *whenGreenFlagClicked6() {
    while (!(this.toNumber(this.stage.vars.game) === 1)) {
      this.stage.vars.jx = 0;
      this.stage.vars.jy = 0;
      yield;
    }
  }

  *whenGreenFlagClicked7() {
    while (true) {
      if (
        this.toNumber(this.stage.vars.lights) === 1 &&
        !this.touching(this.sprites["EnemySensor"].andClones())
      ) {
        this.visible = false;
      }
      yield;
    }
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveEnemySolara() {
    this.visible = true;
    this.stage.vars.enemymove = 1;
    this.goto(this.sprites["Player"].x, this.sprites["Player"].y);
  }

  *startAsClone() {
    this.stage.vars.vent = 0;
    yield* this.wait(this.random(4, 5));
    while (true) {
      if (this.toNumber(this.stage.vars.enemymove) === 0) {
        this.visible = false;
        yield* this.wait(this.random(3, 4));
        yield* this.startSound("Vent 2");
        yield* this.wait(this.random(3, 4));
        if (this.toNumber(this.stage.vars.lights) === 0) {
          if (this.toNumber(this.stage.vars.safe) === 0) {
            if (!(this.toNumber(this.stage.vars.ventnum) === 0)) {
              this.goto(
                this.toNumber(this.stage.vars.playerX) -
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.ventX,
                      this.stage.vars.ventnum - 1
                    )
                  ) +
                  this.toNumber(this.stage.vars.mapX),
                this.toNumber(this.stage.vars.playerY) -
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.ventY,
                      this.stage.vars.ventnum - 1
                    )
                  ) +
                  this.toNumber(this.stage.vars.mapY)
              );
              yield* this.startSound("Vent 1");
              this.direction = 90;
              this.stage.vars.vent = 1;
              this.costume = "Vent 1";
              this.visible = true;
              this.costume = "Vent 1";
              for (let i = 0; i < 3; i++) {
                yield* this.wait(0.04);
                this.costumeNumber++;
                yield;
              }
              yield* this.wait(0.04);
              this.costume = "Standing";
              yield* this.wait(0.1);
              this.stage.vars.vent = 0;
              yield* this.chase();
            }
          }
        }
      }
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      while (!this.touching(this.sprites["Playerdetect"].andClones())) {
        yield;
      }
      yield* this.wait(0.5);
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        if (
          this.toNumber(this.stage.vars.vent) === 0 &&
          this.toNumber(this.stage.vars.antiKill) === 0
        ) {
          this.stage.vars.votedwrong = 0;
          this.broadcast("Defeat");
          /* TODO: Implement stop other scripts in sprite */ null;
          this.visible = false;
        }
      }
      while (!!this.touching(this.sprites["Playerdetect"].andClones())) {
        yield;
      }
      yield;
    }
  }

  *whenIReceiveKillEnemy() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *whenIReceiveFixEnemy() {
    while (true) {
      while (!this.touching(this.sprites["Playerdetect"].andClones())) {
        yield;
      }
      yield* this.wait(0.5);
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        if (
          this.toNumber(this.stage.vars.vent) === 0 &&
          this.toNumber(this.stage.vars.antiKill) === 0
        ) {
          this.stage.vars.votedwrong = 0;
          this.broadcast("Defeat");
          /* TODO: Implement stop other scripts in sprite */ null;
          this.visible = false;
        }
      }
      while (!!this.touching(this.sprites["Playerdetect"].andClones())) {
        yield;
      }
      yield;
    }
  }

  *whenIReceiveFixEnemy2() {
    this.broadcast("Begin game");
  }

  *whenGreenFlagClicked8() {
    while (true) {
      this.stage.vars.enemyy = this.y;
      this.stage.vars.enemyX = this.x;
      yield;
    }
  }
}
