/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Rolescreen extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Role", "./Rolescreen/costumes/Role.svg", {
        x: 250.5,
        y: 272.69752,
      }),
      new Costume("Hmmmmm", "./Rolescreen/costumes/Hmmmmm.svg", {
        x: 165.020505,
        y: 118.74436099535924,
      }),
      new Costume("Defeat", "./Rolescreen/costumes/Defeat.svg", {
        x: 250.5,
        y: 265.980997582854,
      }),
      new Costume("Victory", "./Rolescreen/costumes/Victory.svg", {
        x: 250.5,
        y: 272.6975200000002,
      }),
      new Costume("Defeat2", "./Rolescreen/costumes/Defeat2.svg", {
        x: 250.5,
        y: 190.281179375,
      }),
      new Costume("Hmmmmm2", "./Rolescreen/costumes/Hmmmmm2.svg", {
        x: 243.5483856201172,
        y: 194.84490966796875,
      }),
      new Costume("???", "./Rolescreen/costumes/???.svg", {
        x: -17.664487500000007,
        y: 113.0673775,
      }),
      new Costume(
        "magnifying glass",
        "./Rolescreen/costumes/magnifying glass.svg",
        { x: 57.24746499999998, y: 79.95985999999999 }
      ),
      new Costume("spin", "./Rolescreen/costumes/spin.svg", {
        x: 532.048395,
        y: 409.9004250000001,
      }),
    ];

    this.sounds = [
      new Sound("Role", "./Rolescreen/sounds/Role.wav"),
      new Sound("Wind", "./Rolescreen/sounds/Wind.wav"),
      new Sound("Clue", "./Rolescreen/sounds/Clue.wav"),
      new Sound("Victory", "./Rolescreen/sounds/Victory.mp3"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Victory" },
        this.whenIReceiveVictory
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "delete role reveal clones" },
        this.whenIReceiveDeleteRoleRevealClones
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.visible = false;
  }

  *whenIReceiveShowRole() {
    this.costume = "???";
    this.createClone();
    this.costume = "magnifying glass";
    this.createClone();
    this.costume = "spin";
    this.createClone();
    this.costume = "Hmmmmm";
    this.moveAhead();
    this.stage.vars.game = 1;
    this.visible = true;
    this.effects.ghost = 0;
    yield* this.wait(1.5);
    this.moveBehind();
    this.effects.brightness = -100;
    this.broadcast("delete role reveal clones");
    yield* this.startSound("Role");
    this.costume = "Role";
    for (let i = 0; i < 34; i++) {
      this.effects.brightness += 3;
      yield;
    }
    yield* this.wait(3);
    for (let i = 0; i < 34; i++) {
      this.effects.brightness -= 3;
      yield;
    }
    yield* this.wait(1);
    for (let i = 0; i < 34; i++) {
      this.effects.ghost += 3;
      yield;
    }
    this.broadcast("Begin game");
    while (!(this.toNumber(this.stage.vars.game) === 0)) {
      yield* this.playSoundUntilDone("Wind");
      yield;
    }
  }

  *whenIReceiveDefeat() {
    this.stage.vars.game = 0;
    this.costume = "Defeat";
    this.effects.clear();
    this.moveAhead();
    this.effects.brightness = -100;
    if (this.toNumber(this.stage.vars.votedwrong) === 0) {
      yield* this.wait(3);
    }
    if (this.toNumber(this.stage.vars.winonlose) === 1) {
      /* TODO: Implement stop other scripts in sprite */ null;
      return;
    } else {
      this.visible = true;
      for (let i = 0; i < 34; i++) {
        this.effects.brightness += 3;
        yield;
      }
    }
  }

  *whenIReceiveVictory() {
    yield* this.startSound("Victory");
    this.stage.vars.game = 0;
    this.costume = "Victory";
    this.effects.clear();
    this.moveAhead();
    this.effects.brightness = -100;
    this.visible = true;
    for (let i = 0; i < 34; i++) {
      this.effects.brightness += 3;
      this.stage.watchers.time.visible = true;
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    this.stage.vars.game = 1;
    yield* this.wait(1);
    while (!(this.toNumber(this.stage.vars.game) === 0)) {
      this.stage.vars.seconds++;
      if (this.toNumber(this.stage.vars.seconds) === 60) {
        this.stage.vars.seconds = 0;
        this.stage.vars.minutes++;
      }
      if (this.toNumber(this.stage.vars.minutes) === 60) {
        this.stage.vars.minutes = 0;
        this.stage.vars.hours++;
      }
      yield* this.wait(1);
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.time = "00.00.00";
    this.stage.vars.seconds = 0;
    this.stage.vars.hours = 0;
    this.stage.vars.minutes = 0;
    this.stage.watchers.time.visible = false;
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.stage.vars.hours.length === 1) {
        this.stage.vars.hours = "0" + this.toString(this.stage.vars.hours);
      }
      if (this.stage.vars.minutes.length === 1) {
        this.stage.vars.minutes = "0" + this.toString(this.stage.vars.minutes);
      }
      if (this.stage.vars.seconds.length === 1) {
        this.stage.vars.seconds = "0" + this.toString(this.stage.vars.seconds);
      }
      this.stage.vars.time =
        this.toString(this.stage.vars.hours) +
        " : " +
        (this.toString(this.stage.vars.minutes) +
          (" : " + this.toString(this.stage.vars.seconds)));
      yield;
    }
  }

  *whenIReceiveDeleteRoleRevealClones() {
    this.deleteThisClone();
  }

  *startAsClone() {
    this.moveAhead();
    this.effects.clear();
    this.visible = true;
    if (this.costume.name === "spin") {
      this.moveBehind();
      this.moveAhead(15);
      while (true) {
        this.direction += 2;
        yield;
      }
    }
    if (this.costume.name === "???") {
      while (true) {
        this.visible = true;
        this.moveAhead();
        this.goto(this.random(-10, 10), this.random(-10, 10));
        yield;
      }
    }
    if (this.costume.name === "magnifying glass") {
      this.goto(0, -70);
      yield* this.glide(1.5, 0, 0);
    }
  }
}
