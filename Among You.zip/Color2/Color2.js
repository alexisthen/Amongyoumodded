/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Color2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Purple", "./Color2/costumes/Purple.svg", { x: 22, y: 22 }),
      new Costume("Pink", "./Color2/costumes/Pink.svg", { x: 22, y: 22 }),
      new Costume("Red", "./Color2/costumes/Red.svg", { x: 22, y: 22 }),
      new Costume("Orange", "./Color2/costumes/Orange.svg", { x: 22, y: 22 }),
      new Costume("Yellow", "./Color2/costumes/Yellow.svg", { x: 22, y: 22 }),
      new Costume("Lime", "./Color2/costumes/Lime.svg", { x: 22, y: 22 }),
      new Costume("Cyan", "./Color2/costumes/Cyan.svg", { x: 22, y: 22 }),
      new Costume("Brown", "./Color2/costumes/Brown.svg", { x: 22, y: 22 }),
      new Costume("Blue", "./Color2/costumes/Blue.svg", { x: 22, y: 22 }),
      new Costume("Green", "./Color2/costumes/Green.svg", { x: 22, y: 22 }),
      new Costume("Nothing", "./Color2/costumes/Nothing.svg", { x: 22, y: 22 }),
    ];

    this.sounds = [
      new Sound("pop", "./Color2/sounds/pop.wav"),
      new Sound("Coin2", "./Color2/sounds/Coin2.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickColor" },
        this.whenIReceivePickcolor
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole2
      ),
    ];
  }

  *whenthisspriteclicked() {
    yield* this.startSound("pop");
    if (!(this.costumeNumber === 11 || this.costumeNumber === 12)) {
      this.stage.vars.player = this.costumeNumber;
    }
    if (this.costumeNumber === 1) {
      this.stage.vars.color = 15;
    } else {
      if (this.costumeNumber === 2) {
        this.stage.vars.color = 30;
      } else {
        if (this.costumeNumber === 3) {
          this.stage.vars.color = 60;
        } else {
          if (this.costumeNumber === 4) {
            this.stage.vars.color = 80;
          } else {
            if (this.costumeNumber === 5) {
              this.stage.vars.color = 90;
            } else {
              if (this.costumeNumber === 6) {
                this.stage.vars.color = 120;
              } else {
                if (this.costumeNumber === 7) {
                  this.stage.vars.color = 160;
                } else {
                  if (this.costumeNumber === 8) {
                    this.stage.vars.color = -120;
                  } else {
                    if (this.costumeNumber === 9) {
                      this.stage.vars.color = 0;
                    } else {
                      if (this.costumeNumber === 10) {
                        this.stage.vars.color = -60;
                      } else {
                        if (this.costumeNumber === 11) {
                          yield* this.startSound("Coin2");
                          this.broadcast("PickMap");
                          while (
                            !!(this.mouse.down && this.touching("mouse"))
                          ) {
                            yield;
                          }
                        } else {
                          null;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.mobileMode.visible = false;
    this.visible = false;
    this.goto(60, 105);
    this.costume = "Purple";
    this.size = 100;
    for (let i = 0; i < 3; i++) {
      for (let i = 0; i < 3; i++) {
        this.createClone();
        this.x += 60;
        this.costumeNumber++;
        yield;
      }
      this.y -= 60;
      this.x = 60;
      yield;
    }
    for (let i = 0; i < 2; i++) {
      this.createClone();
      this.x += 60;
      this.costumeNumber++;
      yield;
    }
    this.goto(0, 0);
    this.costume = "Board";
    this.moveAhead();
  }

  *startAsClone() {
    yield* this.wait(0.6);
    this.moveAhead();
  }

  *whenIReceivePickcolor() {
    this.stage.watchers.mobileMode.visible = true;
    this.visible = true;
  }

  *whenIReceiveShowRole() {
    this.visible = false;
  }

  *whenIReceiveShowRole2() {
    this.stage.watchers.mobileMode.visible = false;
  }
}
