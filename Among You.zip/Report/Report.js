/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Report extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Report/costumes/costume1.svg", {
        x: 75.31107271543624,
        y: 78.07630870844528,
      }),
      new Costume("costume2", "./Report/costumes/costume2.svg", {
        x: 108.53343676986694,
        y: 33.36846017187497,
      }),
      new Costume("Report Button", "./Report/costumes/Report Button.svg", {
        x: 106,
        y: 106,
      }),
    ];

    this.sounds = [new Sound("Clue", "./Report/sounds/Clue.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.costume = "costume1";
    this.goto(178, -19);
    this.size = 80;
    this.visible = false;
  }

  *whenIReceiveBeginGame() {
    yield* this.wait(0.35);
    this.moveAhead();
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.toNumber(this.stage.vars.game) === 1) {
        if (this.toNumber(this.stage.vars.report) === 1) {
          this.moveAhead();
          this.visible = true;
        } else {
          this.visible = false;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.mouse.down && this.touching("mouse")) {
        if (this.toNumber(this.stage.vars.report) === 1) {
          this.broadcast("BodyFound");
          yield* this.startSound("Clue");
          this.broadcast("ClueFound");
          while (!!(this.mouse.down && this.touching("mouse"))) {
            yield;
          }
        }
      }
      yield;
    }
  }

  *whenIReceiveDefeat() {
    this.stage.vars.report = 0;
    this.visible = false;
  }
}
