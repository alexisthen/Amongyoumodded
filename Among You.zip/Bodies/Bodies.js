/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bodies extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Repairs", "./Bodies/costumes/Repairs.svg", {
        x: -123.74060500000002,
        y: -76.10894671099032,
      }),
      new Costume("Navigation", "./Bodies/costumes/Navigation.svg", {
        x: 36.96129000000002,
        y: -53.14039842198068,
      }),
      new Costume("East Power", "./Bodies/costumes/East Power.svg", {
        x: 115.56129000000001,
        y: 54.792946489371985,
      }),
      new Costume("West Power", "./Bodies/costumes/West Power.svg", {
        x: -109.43871000000001,
        y: 54.79293828900967,
      }),
      new Costume("Office ", "./Bodies/costumes/Office .svg", {
        x: -49.81370999999996,
        y: 99.54293657801932,
      }),
      new Costume("Office  ", "./Bodies/costumes/Office  .svg", {
        x: 37.550790000000006,
        y: 114.42818328900967,
      }),
      new Costume("Storage", "./Bodies/costumes/Storage.svg", {
        x: -181.75664,
        y: 51.562686724737574,
      }),
      new Costume("Navigation   ", "./Bodies/costumes/Navigation   .svg", {
        x: 11.259105000000005,
        y: -78.69681171099029,
      }),
      new Costume("Security", "./Bodies/costumes/Security.svg", {
        x: 101.38621499999999,
        y: -63.86587275842115,
      }),
      new Costume("Office", "./Bodies/costumes/Office.svg", {
        x: -31.756640000000004,
        y: 96.5626922415792,
      }),
      new Costume("Storage ", "./Bodies/costumes/Storage .svg", {
        x: -214.11587500000002,
        y: 44.428188289009654,
      }),
      new Costume("Navigation  ", "./Bodies/costumes/Navigation  .svg", {
        x: -31.61588499999999,
        y: -49.19681671099033,
      }),
      new Costume("Security ", "./Bodies/costumes/Security .svg", {
        x: 95.54481000000001,
        y: -92.41109171099032,
      }),
    ];

    this.sounds = [new Sound("pop", "./Bodies/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "BodyFound" },
        this.whenIReceiveBodyfound
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "BodyFound" },
        this.whenIReceiveBodyfound2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
    ];

    this.vars.costume = 9;
    this.vars.reportcolor = "Yellow";
    this.vars.bodycolor = 5;
  }

  *startAsClone() {
    while (true) {
      this.effects.ghost = 0;
      yield* this.findcolor();
      this.visible = true;
      this.goto(
        this.toNumber(this.stage.vars.playerX) +
          this.toNumber(this.stage.vars.mapX),
        this.toNumber(this.stage.vars.playerY) +
          this.toNumber(this.stage.vars.mapY)
      );
      yield;
    }
  }

  *startAsClone2() {
    while (true) {
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        this.stage.vars.report = 1;
      } else {
        null;
      }
      yield;
    }
  }

  *whenIReceiveBodyfound() {}

  *findcolor() {
    this.effects.brightness = 0;
    if (
      this.toNumber(
        this.itemOf(this.stage.vars.deadplayers, this.vars.bodycolor - 1)
      ) === 1
    ) {
      this.effects.color = 15;
      this.vars.reportcolor = "Purple";
    } else {
      if (
        this.toNumber(
          this.itemOf(this.stage.vars.deadplayers, this.vars.bodycolor - 1)
        ) === 2
      ) {
        this.effects.color = 30;
        this.vars.reportcolor = "Pink";
      } else {
        if (
          this.toNumber(
            this.itemOf(this.stage.vars.deadplayers, this.vars.bodycolor - 1)
          ) === 3
        ) {
          this.effects.color = 60;
          this.vars.reportcolor = "Red";
        } else {
          if (
            this.toNumber(
              this.itemOf(this.stage.vars.deadplayers, this.vars.bodycolor - 1)
            ) === 4
          ) {
            this.effects.color = 80;
            this.vars.reportcolor = "Orange";
          } else {
            if (
              this.toNumber(
                this.itemOf(
                  this.stage.vars.deadplayers,
                  this.vars.bodycolor - 1
                )
              ) === 5
            ) {
              this.effects.color = 100;
              this.vars.reportcolor = "Yellow";
            } else {
              if (
                this.toNumber(
                  this.itemOf(
                    this.stage.vars.deadplayers,
                    this.vars.bodycolor - 1
                  )
                ) === 6
              ) {
                this.effects.color = 120;
                this.vars.reportcolor = "Lime";
              } else {
                if (
                  this.toNumber(
                    this.itemOf(
                      this.stage.vars.deadplayers,
                      this.vars.bodycolor - 1
                    )
                  ) === 7
                ) {
                  this.effects.color = 160;
                  this.vars.reportcolor = "Cyan";
                } else {
                  if (
                    this.toNumber(
                      this.itemOf(
                        this.stage.vars.deadplayers,
                        this.vars.bodycolor - 1
                      )
                    ) === 8
                  ) {
                    this.effects.color = 90;
                    this.effects.brightness = -30;
                    this.vars.reportcolor = "Brown";
                  } else {
                    if (
                      this.toNumber(
                        this.itemOf(
                          this.stage.vars.deadplayers,
                          this.vars.bodycolor - 1
                        )
                      ) === 9
                    ) {
                      this.effects.color = 0;
                      this.vars.reportcolor = "Blue";
                    } else {
                      if (
                        this.toNumber(
                          this.itemOf(
                            this.stage.vars.deadplayers,
                            this.vars.bodycolor - 1
                          )
                        ) === 10
                      ) {
                        this.effects.color = 120;
                        this.effects.brightness = -40;
                        this.vars.reportcolor = "Green";
                      } else {
                        if (
                          this.toNumber(
                            this.itemOf(
                              this.stage.vars.deadplayers,
                              this.vars.bodycolor - 1
                            )
                          ) === 11
                        ) {
                          this.costume = this.random(9, 10);
                          this.vars.reportcolor = "Black";
                        } else {
                          if (
                            this.toNumber(
                              this.itemOf(
                                this.stage.vars.deadplayers,
                                this.vars.bodycolor - 1
                              )
                            ) === 12
                          ) {
                            this.costume = "Storage";
                            this.vars.reportcolor = "White";
                          } else {
                            null;
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  *whenIReceiveBeginGame() {
    this.effects.ghost = 0;
    yield* this.wait(0.1);
    this.moveAhead();
  }

  *whenIReceiveBodyfound2() {
    if (this.touching(this.sprites["Playerdetect"].andClones())) {
      this.stage.vars.evidence.push(
        this.toString(this.vars.reportcolor) + (" Body: " + this.costume.name)
      );
      this.stage.vars.report = 0;
      this.deleteThisClone();
    }
  }

  *whenIReceiveBeginGame2() {
    this.visible = false;
    this.costume = this.random(1, 13);
    this.vars.costume = this.costumeNumber;
    this.costume = this.random(1, 13);
    this.size = 800;
    this.costume = this.random(1, 13);
    this.costume = this.vars.costume;
    this.effects.ghost = 100;
    this.vars.bodycolor = 0;
    for (let i = 0; i < this.stage.vars.deadplayers.length; i++) {
      this.vars.bodycolor++;
      this.createClone();
      this.costumeNumber++;
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone3() {
    while (true) {
      if (this.touching("edge")) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }
}
