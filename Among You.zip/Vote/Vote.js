/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Vote extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Purple", "./Vote/costumes/Purple.svg", {
        x: 40.08414500000009,
        y: 54.34551499999999,
      }),
      new Costume("Pink", "./Vote/costumes/Pink.svg", {
        x: 40.08414500000012,
        y: 54.34550499999999,
      }),
      new Costume("Red", "./Vote/costumes/Red.svg", {
        x: 40.08414500000012,
        y: 54.34550499999999,
      }),
      new Costume("Orange", "./Vote/costumes/Orange.svg", {
        x: 40.08414500000015,
        y: 54.345504999999974,
      }),
      new Costume("Yellow", "./Vote/costumes/Yellow.svg", {
        x: 40.08414500000015,
        y: 54.345504999999974,
      }),
      new Costume("Lime", "./Vote/costumes/Lime.svg", {
        x: 40.08414500000015,
        y: 54.345504999999974,
      }),
      new Costume("Cyan", "./Vote/costumes/Cyan.svg", {
        x: 40.08414500000018,
        y: 54.34550499999996,
      }),
      new Costume("Brown", "./Vote/costumes/Brown.svg", {
        x: 40.084145000000206,
        y: 54.345504999999946,
      }),
      new Costume("Blue", "./Vote/costumes/Blue.svg", {
        x: 40.084145000000234,
        y: 54.34550499999993,
      }),
      new Costume("Green", "./Vote/costumes/Green.svg", {
        x: 40.084145000000234,
        y: 54.34550499999993,
      }),
      new Costume("Black", "./Vote/costumes/Black.svg", {
        x: 40.08414500000026,
        y: 54.34550499999992,
      }),
      new Costume("White", "./Vote/costumes/White.svg", {
        x: 40.08414500000001,
        y: 54.345505,
      }),
      new Costume("RIght", "./Vote/costumes/RIght.svg", {
        x: 15.571038892220514,
        y: 24.211684594761522,
      }),
      new Costume("Left", "./Vote/costumes/Left.svg", {
        x: 15.456050089500877,
        y: 24.21168950462939,
      }),
    ];

    this.sounds = [new Sound("Coin2", "./Vote/sounds/Coin2.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.BROADCAST, { name: "Left" }, this.whenIReceiveLeft),
      new Trigger(Trigger.BROADCAST, { name: "Right" }, this.whenIReceiveRight),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
    ];

    this.vars.original = 0;
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.size = 100;
    this.goto(-93, -40);
    this.vars.original = 1;
    this.costume = "Left";
    this.createClone();
    this.costume = "RIght";
    this.createClone();
    this.costume = "Purple";
    this.vars.original = 0;
    while (true) {
      this.stage.vars.votedcolor = this.costumeNumber;
      yield;
    }
  }

  *startAsClone() {
    this.size = 150;
    if (this.costumeNumber === 13) {
      this.goto(20, 0);
      this.moveAhead();
    }
    if (this.costumeNumber === 14) {
      this.goto(-210, 0);
      this.moveAhead();
    }
  }

  *whenthisspriteclicked() {
    if (this.costumeNumber === 13) {
      yield* this.startSound("Coin2");
      this.broadcast("Right");
    }
    if (this.costumeNumber === 14) {
      yield* this.startSound("Coin2");
      this.broadcast("Left");
    }
  }

  *whenIReceiveLeft() {
    if (this.toNumber(this.vars.original) === 0) {
      this.costume = this.costumeNumber - 1;
      if (this.costumeNumber === 14) {
        this.costume = "White";
      }
      if (this.compare(this.costumeNumber, this.stage.vars.player) === 0) {
        this.costume = this.costumeNumber - 1;
      }
    }
  }

  *whenIReceiveRight() {
    if (this.toNumber(this.vars.original) === 0) {
      this.costumeNumber++;
      if (this.costumeNumber === 13) {
        this.costume = "Purple";
      }
      if (this.compare(this.costumeNumber, this.stage.vars.player) === 0) {
        this.costumeNumber++;
      }
    }
  }

  *whenIReceiveEmergencyMeeting() {
    this.visible = true;
    yield* this.wait(0.2);
    this.moveAhead();
    if (!(this.costumeNumber === 13 || this.costumeNumber === 14)) {
      this.costume = "White";
    }
  }

  *whenIReceiveStopmeeting() {
    this.visible = false;
  }
}
