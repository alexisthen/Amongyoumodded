/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class EnemySensor extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./EnemySensor/costumes/costume1.svg", {
        x: 134.89639,
        y: 134.89638,
      }),
    ];

    this.sounds = [new Sound("pop", "./EnemySensor/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickColor" },
        this.whenIReceivePickcolor
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickMap" },
        this.whenIReceivePickmap
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, 0);
    this.effects.ghost = 100;
    this.visible = true;
    this.stage.watchers.mobile.visible = false;
  }

  *whenIReceivePickcolor() {
    this.stage.watchers.mobile.visible = true;
    while (true) {
      if (this.toNumber(this.stage.vars.mobileMode) === 0) {
        this.stage.vars.mobile = "OFF";
      } else {
        this.stage.vars.mobile = "ON";
      }
      yield;
    }
  }

  *whenIReceivePickmap() {
    this.stage.watchers.mobile.visible = false;
  }
}
