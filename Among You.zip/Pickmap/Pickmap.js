/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Pickmap extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Map1", "./Pickmap/costumes/Map1.svg", {
        x: 232,
        y: 48.88889000000006,
      }),
      new Costume(
        "The Bauderator Unlocked",
        "./Pickmap/costumes/The Bauderator Unlocked.svg",
        { x: 232, y: 48.88889000000006 }
      ),
      new Costume(
        "The Bauderator Locked",
        "./Pickmap/costumes/The Bauderator Locked.svg",
        { x: 232, y: 48.88889000000003 }
      ),
      new Costume("Not Ready", "./Pickmap/costumes/Not Ready.svg", {
        x: 232,
        y: 48.88889000000012,
      }),
    ];

    this.sounds = [new Sound("pop", "./Pickmap/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "PickMap" },
        this.whenIReceivePickmap
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.costume = "Map1";
    this.goto(0, 100);
    this.createClone();
  }

  *startAsClone() {
    this.costume = "The Bauderator Unlocked";
    this.goto(0, -100);
  }

  *whenIReceivePickmap() {
    this.stage.watchers.mobileMode.visible = false;
    this.visible = true;
    this.moveAhead();
  }

  *whenthisspriteclicked() {
    if (this.costumeNumber === 1) {
      this.stage.vars.gamemap = 1;
      this.broadcast("Map1");
      this.broadcast("Show Role");
    } else {
      this.stage.vars.gamemap = 2;
      this.broadcast("TheBaulderator");
      this.broadcast("Show Role");
    }
  }

  *whenIReceiveShowRole() {
    this.visible = false;
  }

  *startAsClone2() {
    this.costume = "Not Ready";
  }
}
