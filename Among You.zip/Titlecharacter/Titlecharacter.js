/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Titlecharacter extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Costume2", "./Titlecharacter/costumes/Costume2.svg", {
        x: 106.6400182145689,
        y: 59.42951643867059,
      }),
    ];

    this.sounds = [new Sound("pop", "./Titlecharacter/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = true;
    this.goto(0, 0);
    this.size = 70;
    while (true) {
      this.direction -= 0.5;
      this.effects.color += 0.5;
      yield;
    }
  }

  *whenIReceiveShowRole() {
    this.visible = false;
  }

  *whenGreenFlagClicked2() {
    yield* this.sayAndWait("check my yt out its in the instruction", 5);
  }
}
