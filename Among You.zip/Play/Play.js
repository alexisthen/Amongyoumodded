/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Play extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume3", "./Play/costumes/costume3.svg", {
        x: 69.42232999999999,
        y: 31.75,
      }),
      new Costume("costume1", "./Play/costumes/costume1.svg", {
        x: 69.42232999999999,
        y: 31.75,
      }),
    ];

    this.sounds = [
      new Sound("SELECT", "./Play/sounds/SELECT.wav"),
      new Sound("Menu Music2", "./Play/sounds/Menu Music2.wav"),
      new Sound("Coin2", "./Play/sounds/Coin2.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Show Role" },
        this.whenIReceiveShowRole
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.goto(0, -130);
    this.visible = true;
    while (true) {
      if (this.toNumber(this.stage.vars.game) === 0) {
        if (this.touching("mouse")) {
          yield* this.startSound("SELECT");
          this.costume = "costume3";
          while (!!this.touching("mouse")) {
            yield;
          }
        } else {
          this.costume = "costume1";
        }
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    this.broadcast("PickColor");
  }

  *whenGreenFlagClicked2() {
    while (true) {
      this.effects.color += 0.5;
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.stage.vars.game = 0;
    while (!(this.toNumber(this.stage.vars.game) === 1)) {
      yield* this.playSoundUntilDone("Menu Music2");
      yield;
    }
  }

  *whenIReceiveShowRole() {
    this.visible = false;
    this.stopAllSounds();
  }
}
