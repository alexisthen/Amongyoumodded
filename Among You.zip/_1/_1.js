/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class _1 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./_1/costumes/costume1.svg", {
        x: 327.04355170168793,
        y: 187.71122478695483,
      }),
    ];

    this.sounds = [new Sound("pop", "./_1/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.KEY_PRESSED, { key: "1" }, this.whenKey1Pressed),
      new Trigger(Trigger.BROADCAST, { name: "cool" }, this.whenIReceiveCool),
      new Trigger(
        Trigger.BROADCAST,
        { name: "AHHHHHHHHHH" },
        this.whenIReceiveAhhhhhhhhhh
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "ANTI-AAAAAAAAAAA" },
        this.whenIReceiveAntiAaaaaaaaaaa
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];
  }

  *whenKey1Pressed() {
    yield* this.askAndWait(
      "Selora Cheat Inject V1   1-- GoImp 2--ChangeImp 3--BringImp 4--AntiCatch:True 5--AntiCatch:False 6--DestroyEnemy 7-EndGame(Defeat) 8--EndGame(Win) 9--ForceMeeting 10--ShowDeadIds 11--HideDead 12--NoLightCoolDown 13--EnableCoolDown 14--Permenatly Break Enemy 15--Fix Enemy 16--Reset Game/Bypass Color 17--Show YX 18--HideYX 19--RGB 20--DisableRGB 21--AlwaysWin 22--DisableAlwaysWin 23--TPRANDOM 24--Clone Player RIG"
    );
    this.visible = false;
    if (this.toNumber(this.answer) === 1) {
      this.stage.vars.playerY = this.stage.vars.enemyy;
      this.stage.vars.playerX = this.stage.vars.enemyX;
      this.broadcast("TP to enemy");
    }
    if (this.toNumber(this.answer) === 2) {
      yield* this.askAndWait("Imposter ID");
      this.stage.vars.impostor = this.answer;
    }
    if (this.toNumber(this.answer) === 3) {
      this.stage.vars.enemyX = this.stage.vars.playerX;
      this.stage.vars.enemyy = this.stage.vars.playerY;
      this.broadcast("enemy solara");
    }
    if (this.toNumber(this.answer) === 4) {
      this.stage.vars.antiKill = 1;
    }
    if (this.toNumber(this.answer) === 5) {
      this.stage.vars.antiKill = 0;
    }
    if (this.toNumber(this.answer) === 7) {
      this.broadcast("Defeat");
    }
    if (this.toNumber(this.answer) === 8) {
      this.broadcast("Victory");
    }
    if (this.toNumber(this.answer) === 9) {
      this.broadcast("Emergency Meeting");
      this.stage.watchers.evidence.visible = true;
    }
    if (this.toNumber(this.answer) === 10) {
      this.stage.watchers.deadplayers.visible = true;
    }
    if (this.toNumber(this.answer) === 11) {
      this.stage.watchers.deadplayers.visible = false;
    }
    if (this.toNumber(this.answer) === 12) {
      this.broadcast("cool");
    }
    if (this.toNumber(this.answer) === 13) {
      /* TODO: Implement stop other scripts in sprite */ null;
    }
    if (this.toNumber(this.answer) === 14) {
      this.broadcast("kill enemy");
    }
    if (this.toNumber(this.answer) === 15) {
      this.broadcast("fix enemy");
    }
    if (this.toNumber(this.answer) === 16) {
      this.broadcast("Begin game");
    }
    if (this.toNumber(this.answer) === 17) {
      this.stage.watchers.enemymove.visible = true;
      this.stage.watchers.enemyX.visible = true;
      this.stage.watchers.enemyy.visible = true;
      this.stage.watchers.playerX.visible = true;
      this.stage.watchers.playerspeed.visible = true;
      this.stage.watchers.playerY.visible = true;
    }
    if (this.toNumber(this.answer) === 18) {
      this.stage.watchers.enemyy.visible = false;
      this.stage.watchers.enemyX.visible = false;
      this.stage.watchers.enemymove.visible = false;
      this.stage.watchers.playerY.visible = false;
      this.stage.watchers.playerX.visible = false;
      this.stage.watchers.playerspeed.visible = false;
    }
    if (this.toNumber(this.answer) === 19) {
      this.broadcast("AHHHHHHHHHH");
    }
    if (this.toNumber(this.answer) === 20) {
      this.broadcast("ANTI-AAAAAAAAAAA");
    }
    if (this.toNumber(this.answer) === 21) {
      this.stage.vars.winonlose = 1;
    }
    if (this.toNumber(this.answer) === 22) {
      this.stage.vars.winonlose = 0;
    }
    if (this.toNumber(this.answer) === 23) {
      this.broadcast("Teleport");
    }
    if (this.toNumber(this.answer) === 24) {
      this.sprites["Player"].createClone();
    }
  }

  *whenIReceiveCool() {
    while (true) {
      this.stage.vars.lightscooldown = 0;
      yield;
    }
  }

  *whenIReceiveAhhhhhhhhhh() {
    while (true) {
      this.stage.vars.color++;
      yield;
    }
  }

  *whenIReceiveAntiAaaaaaaaaaa() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *whenIReceiveDefeat() {
    if (this.toNumber(this.stage.vars.winonlose) === 1) {
      yield* this.wait(3.2);
      this.broadcast("Victory");
    }
  }

  *whenGreenFlagClicked() {
    this.stage.vars.winonlose = 0;
    this.stage.vars.antiKill = 0;
  }
}
