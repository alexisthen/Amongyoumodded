/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class BearTraps extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("open", "./BearTraps/costumes/open.svg", {
        x: 18.8898447745118,
        y: 25.029274568050056,
      }),
      new Costume("closed", "./BearTraps/costumes/closed.svg", {
        x: 18.85233463505611,
        y: 18.196410140568247,
      }),
    ];

    this.sounds = [new Sound("Crunch", "./BearTraps/sounds/Crunch.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
    ];

    this.vars.trapx = 0;
    this.vars.trapy = 0;
  }

  *whenGreenFlagClicked() {
    this.stage.vars.move = 0;
    this.costume = "closed";
    this.visible = false;
    for (let i = 0; i < this.random(17, 23); i++) {
      this.createClone();
      yield;
    }
  }

  *whenIReceiveBeginGame() {
    if (this.costumeNumber === 1) {
      this.rotationStyle = Sprite.RotationStyle.DONT_ROTATE;
      this.vars.trapx = this.random(3000, -3000);
      this.vars.trapy = this.random(1000, -1000);
      this.costume = "open";
      this.goto(
        this.toNumber(this.stage.vars.playerX) -
          this.toNumber(this.vars.trapx) +
          this.toNumber(this.stage.vars.mapX),
        this.toNumber(this.stage.vars.playerY) -
          this.toNumber(this.vars.trapy) +
          this.toNumber(this.stage.vars.mapY)
      );
      if (this.touching(this.sprites["Walls"].andClones())) {
        this.direction = this.random(-179, 180);
        while (!!this.touching(this.sprites["Walls"].andClones())) {
          this.move(1);
          yield;
        }
      }
      while (true) {
        this.goto(
          this.toNumber(this.stage.vars.playerX) -
            this.toNumber(this.vars.trapx) +
            this.toNumber(this.stage.vars.mapX),
          this.toNumber(this.stage.vars.playerY) -
            this.toNumber(this.vars.trapy) +
            this.toNumber(this.stage.vars.mapY)
        );
        if (this.touching("edge")) {
          this.visible = false;
        } else {
          this.visible = true;
        }
        yield;
      }
    }
  }

  *startAsClone() {
    this.costume = "open";
  }

  *whenIReceiveBeginGame2() {
    if (this.costumeNumber === 1) {
      while (!this.touching(this.sprites["Player"].andClones())) {
        yield;
      }
      this.stage.vars.touch = "true";
      this.stage.vars.move = 1;
      this.costume = "closed";
      yield* this.startSound("Crunch");
      yield* this.wait(this.random(2, 4));
      this.stage.vars.move = 0;
      this.stage.vars.touch = "false";
      this.deleteThisClone();
    }
  }
}
