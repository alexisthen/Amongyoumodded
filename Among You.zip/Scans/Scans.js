/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Scans extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("1", "./Scans/costumes/1.svg", {
        x: 156.751775,
        y: -11.05095,
      }),
      new Costume("2", "./Scans/costumes/2.svg", {
        x: 125.807325,
        y: 52.67127333333332,
      }),
      new Costume("3", "./Scans/costumes/3.svg", { x: 94.22796, y: 81.22683 }),
      new Costume("4", "./Scans/costumes/4.svg", { x: 83.608915, y: 81.22682 }),
      new Costume("5", "./Scans/costumes/5.svg", {
        x: 104.069975,
        y: -52.89926000000003,
      }),
      new Costume("6", "./Scans/costumes/6.svg", {
        x: 65.194975,
        y: -76.14925999999997,
      }),
      new Costume("7", "./Scans/costumes/7.svg", {
        x: -29.01212499999997,
        y: 3.032379999999989,
      }),
      new Costume("8", "./Scans/costumes/8.svg", {
        x: -66.01212499999997,
        y: 15.53237999999999,
      }),
      new Costume("9", "./Scans/costumes/9.svg", {
        x: -60.67516499999999,
        y: -76.15574999999995,
      }),
      new Costume("10", "./Scans/costumes/10.svg", {
        x: -97.53230500000001,
        y: -52.15575000000001,
      }),
      new Costume("11", "./Scans/costumes/11.svg", {
        x: -121.98685499999999,
        y: -52.519390000000044,
      }),
      new Costume("12", "./Scans/costumes/12.svg", {
        x: -149.137115,
        y: 56.907379999999975,
      }),
      new Costume("13", "./Scans/costumes/13.svg", {
        x: -120.13711499999994,
        y: 59.15737999999999,
      }),
      new Costume("14", "./Scans/costumes/14.svg", {
        x: -84.51210500000002,
        y: 80.65737999999999,
      }),
      new Costume("15", "./Scans/costumes/15.svg", {
        x: -96.137115,
        y: 80.65737999999999,
      }),
      new Costume("16", "./Scans/costumes/16.svg", {
        x: 13.317434999999989,
        y: -33.67852500000001,
      }),
      new Costume("17", "./Scans/costumes/17.svg", {
        x: -7.797689999999989,
        y: -33.246195,
      }),
      new Costume("18", "./Scans/costumes/18.svg", {
        x: 19.460375,
        y: 118.52800500000001,
      }),
      new Costume("19", "./Scans/costumes/19.svg", {
        x: -14.088009999999997,
        y: 119.011875,
      }),
      new Costume("costume1", "./Scans/costumes/costume1.svg", {
        x: 0.75,
        y: 2.4499969482421875,
      }),
    ];

    this.sounds = [new Sound("pop", "./Scans/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "ClueFound" },
        this.whenIReceiveCluefound
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
    ];

    this.vars.costume = 18;
  }

  *whenGreenFlagClicked() {
    this.goto(-565, -105);
    this.visible = false;
    this.costume = this.random(1, 19);
    this.vars.costume = this.costumeNumber;
    this.costume = "costume1";
    this.size = 800;
    this.costume = this.vars.costume;
    this.costumeNumber++;
    for (let i = 0; i < 9; i++) {
      this.createClone();
      this.costumeNumber++;
      yield;
    }
    this.costumeNumber++;
    for (let i = 0; i < 9; i++) {
      this.createClone();
      this.costumeNumber++;
      yield;
    }
  }

  *startAsClone() {
    this.visible = false;
    this.moveAhead();
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
  }

  *whenIReceiveCluefound() {
    if (this.touching(this.sprites["Playerdetect"].andClones())) {
      this.deleteThisClone();
    }
  }

  *whenIReceiveBeginGame2() {
    while (true) {
      this.goto(this.sprites["Walls"].x, this.sprites["Walls"].y);
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        this.stage.vars.use = 2;
      }
      if (this.touching("edge")) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }
}
