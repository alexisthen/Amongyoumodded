/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Playerdetect extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume6", "./Playerdetect/costumes/costume6.svg", {
        x: 37.03636500000002,
        y: 53.60925,
      }),
    ];

    this.sounds = [new Sound("pop", "./Playerdetect/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Pick role" },
        this.whenIReceivePickRole
      ),
      new Trigger(Trigger.BROADCAST, { name: "Start" }, this.whenIReceiveStart),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame3
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveBeginGame() {
    yield* this.wait(1);
    this.visible = true;
    while (true) {
      yield* this.movement();
      yield;
    }
  }

  *movement() {
    this.size = 43;
    this.rotationStyle = Sprite.RotationStyle.LEFT_RIGHT;
    this.goto(
      0 + this.toNumber(this.stage.vars.mapX),
      0 + this.toNumber(this.stage.vars.mapY)
    );
  }

  *whenIReceiveBeginGame2() {
    this.direction = 90;
    this.moveAhead();
    this.effects.ghost = 100;
  }

  *whenIReceivePickRole() {
    for (let i = 0; i < 20; i++) {
      this.effects.brightness -= 5;
      yield;
    }
  }

  *whenIReceiveStart() {}

  *whenIReceiveBeginGame3() {}

  *whenGreenFlagClicked2() {
    while (true) {
      while (!!this.touching(this.sprites["MapSensor"].andClones())) {
        yield;
      }
      this.stage.vars.lights = 0;
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    this.stage.vars.mobileMode = 0;
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (!this.touching(this.sprites["Clues"].andClones())) {
        this.stage.vars.clue = 0;
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (!this.touching(this.sprites["Bodies"].andClones())) {
        this.stage.vars.report = 0;
      }
      yield;
    }
  }
}
