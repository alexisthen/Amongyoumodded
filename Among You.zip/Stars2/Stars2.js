/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stars2 extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("ColorStar", "./Stars2/costumes/ColorStar.svg", {
        x: 2.5,
        y: 2.5,
      }),
      new Costume("ColorStar2", "./Stars2/costumes/ColorStar2.svg", {
        x: 2.5,
        y: 5.375,
      }),
      new Costume("Star", "./Stars2/costumes/Star.svg", { x: 2.5, y: 2.5 }),
      new Costume("Star2", "./Stars2/costumes/Star2.svg", { x: 2.5, y: 6.125 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Pick role" },
        this.whenIReceivePickRole
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
    ];

    this.vars.starspeed = 0.5392599801198843;
  }

  *whenGreenFlagClicked() {
    this.visible = true;
    this.goto(0, 0);
    this.moveBehind();
    while (true) {
      this.effects.color += 0.5;
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    this.stage.vars.game = 0;
    while (!(this.toNumber(this.stage.vars.game) === 1)) {
      yield* this.wait(1);
      this.createClone();
      yield;
    }
    this.visible = false;
  }

  *startAsClone() {
    this.vars.starspeed = this.random(0.1, 1);
    this.y = -180;
    this.x = this.random(-240, 240);
    if (this.random(1, 4) === 1) {
      this.costume = "ColorStar";
    } else {
      this.costume = "Star";
    }
    this.size = this.random(90, 170);
    while (!(this.compare(this.y, 179) > 0)) {
      this.effects.color += 0.5;
      this.y += this.toNumber(this.vars.starspeed);
      yield;
    }
    this.deleteThisClone();
  }

  *startAsClone2() {
    while (true) {
      for (let i = 0; i < 10; i++) {
        this.effects.ghost -= 8;
        yield;
      }
      for (let i = 0; i < 10; i++) {
        this.effects.ghost += 8;
        yield;
      }
      yield;
    }
  }

  *whenIReceivePickRole() {
    this.visible = false;
    this.deleteThisClone();
  }

  *startAsClone3() {
    while (!(this.toNumber(this.stage.vars.game) === 1)) {
      yield;
    }
    this.deleteThisClone();
  }
}
