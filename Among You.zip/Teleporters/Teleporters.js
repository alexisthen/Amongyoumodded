/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Teleporters extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Report", "./Teleporters/costumes/Report.svg", {
        x: 214.91001217135636,
        y: -32.77017000000001,
      }),
      new Costume("Party Room", "./Teleporters/costumes/Party Room.svg", {
        x: 5.803937150595232,
        y: 75.578325,
      }),
      new Costume("Navigation", "./Teleporters/costumes/Navigation.svg", {
        x: 6.303932150595244,
        y: -86.75502,
      }),
      new Costume("Storage", "./Teleporters/costumes/Storage.svg", {
        x: -184.94607284940474,
        y: 56.99498,
      }),
      new Costume("costume1", "./Teleporters/costumes/costume1.svg", {
        x: 0.25,
        y: 0.25,
      }),
      new Costume("costume2", "./Teleporters/costumes/costume2.svg", {
        x: 0,
        y: 0,
      }),
    ];

    this.sounds = [new Sound("pop", "./Teleporters/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Teleport" },
        this.whenIReceiveTeleport
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
    ];

    this.vars.costume = 1;
  }

  *whenGreenFlagClicked() {
    this.costume = "Report";
    this.vars.costume = this.costumeNumber;
    this.costume = "costume1";
    this.size = 800;
    this.costume = this.vars.costume;
    this.visible = false;
    for (let i = 0; i < 4; i++) {
      this.createClone();
      this.costumeNumber++;
      yield;
    }
    this.costume = "costume2";
  }

  *whenIReceiveBeginGame() {
    if (!(this.costumeNumber === 5)) {
      this.visible = true;
    }
  }

  *whenIReceiveTeleport() {
    if (this.touching(this.sprites["Playerdetect"].andClones())) {
      this.stage.vars.teleport = this.random(1, 4);
      while (
        !!(this.compare(this.stage.vars.teleport, this.costumeNumber) === 0)
      ) {
        this.stage.vars.teleport = this.random(1, 4);
        yield;
      }
      if (this.toNumber(this.stage.vars.teleport) === 1) {
        this.stage.vars.playerX = 1665;
        this.stage.vars.playerY = 265;
      }
      if (this.toNumber(this.stage.vars.teleport) === 2) {
        this.stage.vars.playerX = -10;
        this.stage.vars.playerY = -600;
      }
      if (this.toNumber(this.stage.vars.teleport) === 3) {
        this.stage.vars.playerX = -5;
        this.stage.vars.playerY = 695;
      }
      if (this.toNumber(this.stage.vars.teleport) === 4) {
        this.stage.vars.playerX = -1535;
        this.stage.vars.playerY = -455;
      }
    }
  }

  *whenIReceiveBeginGame2() {
    this.stage.vars.playerX = 1550;
    this.stage.vars.playerY = 215;
    while (true) {
      this.goto(this.sprites["Walls"].x, this.sprites["Walls"].y);
      if (this.touching(this.sprites["Playerdetect"].andClones())) {
        this.stage.vars.use = 3;
      }
      if (this.touching("edge")) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }
}
