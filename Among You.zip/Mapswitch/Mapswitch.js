/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Mapswitch extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Mapswitch/costumes/costume1.svg", {
        x: -133.75,
        y: -89.05001499999997,
      }),
      new Costume("costume2", "./Mapswitch/costumes/costume2.svg", {
        x: -133.75,
        y: -89.05001499999997,
      }),
    ];

    this.sounds = [new Sound("pop", "./Mapswitch/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.size = 80;
    this.goto(0, 0);
    this.stage.vars.maptype = 0;
    this.costume = "costume1";
    while (true) {
      this.moveAhead();
      if (!(this.toNumber(this.stage.vars.showmap) === 0)) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      if (this.toNumber(this.stage.vars.maptype) === 1) {
        this.costume = "costume1";
      } else {
        this.costume = "costume2";
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.toNumber(this.stage.vars.maptype) === 1) {
      this.stage.vars.maptype = 2;
      this.costume = "costume2";
    } else {
      this.stage.vars.maptype = 1;
      this.costume = "costume1";
    }
  }

  *whenIReceiveDefeat() {
    this.stage.vars.showmap = 0;
  }
}
