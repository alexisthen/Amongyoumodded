/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class MapDecoration extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./MapDecoration/costumes/costume1.svg", {
        x: 0.33813593664473274,
        y: 0.49677571242034446,
      }),
      new Costume("Map1", "./MapDecoration/costumes/Map1.svg", {
        x: 217.9031349999998,
        y: 125.69993,
      }),
      new Costume("Map2", "./MapDecoration/costumes/Map2.svg", {
        x: 248.72695640775856,
        y: 241.46604,
      }),
      new Costume("costume2", "./MapDecoration/costumes/costume2.svg", {
        x: 127.457275,
        y: 108.22924,
      }),
      new Costume("costume3", "./MapDecoration/costumes/costume3.svg", {
        x: 10.102615356445312,
        y: 15.140100479125977,
      }),
      new Costume(
        "vending machine",
        "./MapDecoration/costumes/vending machine.svg",
        { x: 42.5, y: 45.5 }
      ),
      new Costume(
        "mira cafeteria",
        "./MapDecoration/costumes/mira cafeteria.svg",
        { x: 71, y: 28.5 }
      ),
      new Costume(
        "weapons chair",
        "./MapDecoration/costumes/weapons chair.svg",
        { x: 82, y: 82.5 }
      ),
      new Costume("costume4", "./MapDecoration/costumes/costume4.svg", {
        x: 16.857675552368164,
        y: 21.103010177612305,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat2
      ),
    ];

    this.vars.costume = 2;
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
    if (this.toNumber(this.stage.vars.gamemap) === 1) {
      this.costume = "Map1";
    } else {
      this.costume = "Map2";
    }
    this.vars.costume = this.costumeNumber;
    this.costume = "costume1";
    this.size = 800;
    this.costume = this.vars.costume;
    while (true) {
      this.goto(this.sprites["Walls"].x, this.sprites["Walls"].y);
      this.moveBehind();
      yield;
    }
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveDefeat2() {
    this.stage.vars.game = 0;
    this.stage.vars.use = 0;
    this.stage.vars.clue = 0;
    this.stage.vars.report = 0;
    this.stage.vars.safe = 1;
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
