/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Buttons extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Buttons/costumes/costume1.svg", {
        x: -182.375,
        y: 175.625,
      }),
      new Costume("costume2", "./Buttons/costumes/costume2.svg", {
        x: 222.625,
        y: 152.88352272727272,
      }),
    ];

    this.sounds = [new Sound("pop", "./Buttons/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Emergency Meeting" },
        this.whenIReceiveEmergencyMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "StopMeeting" },
        this.whenIReceiveStopmeeting
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked4),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.stage.vars.showmap = 0;
    this.visible = false;
  }

  *whenIReceiveBeginGame() {
    this.visible = true;
  }

  *whenthisspriteclicked() {
    if (this.toNumber(this.stage.vars.searching) === 0) {
      if (this.toNumber(this.stage.vars.showmap) === 1) {
        this.stage.vars.maptype = 0;
        this.stage.vars.showmap = 0;
        while (!!(this.mouse.down && this.touching("mouse"))) {
          yield;
        }
      } else {
        this.stage.vars.maptype = 1;
        this.stage.vars.showmap = 1;
        while (!!(this.mouse.down && this.touching("mouse"))) {
          yield;
        }
      }
    }
  }

  *whenGreenFlagClicked2() {
    this.goto(0, 0);
    while (true) {
      this.moveAhead();
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.toNumber(this.stage.vars.showmap) === 1) {
        this.costume = "costume2";
      } else {
        this.costume = "costume1";
      }
      yield;
    }
  }

  *whenIReceiveDefeat() {
    this.visible = false;
  }

  *whenthisspriteclicked2() {
    this.stage.vars.joystick = 0;
    while (!!(this.mouse.down && this.touching("mouse"))) {
      yield;
    }
    this.stage.vars.joystick = 1;
  }

  *whenthisspriteclicked3() {
    this.stage.vars.joystick = 0;
    while (!!(this.mouse.down && this.touching("mouse"))) {
      yield;
    }
    this.stage.vars.joystick = 1;
  }

  *whenIReceiveEmergencyMeeting() {
    this.visible = false;
  }

  *whenIReceiveStopmeeting() {
    this.visible = true;
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.toNumber(this.stage.vars.searching) === 1) {
        this.costume = "costume2";
      }
      yield;
    }
  }

  *whenthisspriteclicked4() {
    if (this.toNumber(this.stage.vars.searching) === 1) {
      this.stage.vars.searching = 0;
      this.stage.vars.move = 0;
      this.costume = "costume1";
    }
  }

  *whenIReceiveDefeat2() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
