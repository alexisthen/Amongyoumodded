/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Cluefound extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./Cluefound/costumes/costume1.svg", {
        x: 115.93820948295594,
        y: 32.029413000000005,
      }),
      new Costume("costume2", "./Cluefound/costumes/costume2.svg", {
        x: 157.04682702484132,
        y: 32.131575,
      }),
    ];

    this.sounds = [new Sound("pop", "./Cluefound/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "ClueFound" },
        this.whenIReceiveCluefound
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.goto(0, 0);
    while (true) {
      this.moveAhead();
      yield;
    }
  }

  *whenIReceiveCluefound() {
    if (this.toString(this.stage.vars.scanChecker) === "false") {
      this.costume = "costume1";
      this.goto(0, -180);
      this.visible = true;
      for (let i = 0; i < 10; i++) {
        this.y += 20;
        yield;
      }
      yield* this.wait(1);
      this.visible = false;
    } else {
      this.costume = "costume2";
      this.goto(0, -180);
      this.visible = true;
      for (let i = 0; i < 10; i++) {
        this.y += 20;
        yield;
      }
      yield* this.wait(1);
      this.visible = false;
    }
  }

  *whenIReceiveDefeat() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }
}
