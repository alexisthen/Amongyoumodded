/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Button extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("background", "./Button/costumes/background.svg", {
        x: 167.75,
        y: 164.305555,
      }),
      new Costume("button", "./Button/costumes/button.svg", {
        x: 51.01150777777778,
        y: 73.311105,
      }),
    ];

    this.sounds = [
      new Sound("Afro String2", "./Button/sounds/Afro String2.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Meeting" },
        this.whenIReceiveMeeting
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Defeat" },
        this.whenIReceiveDefeat
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Begin game" },
        this.whenIReceiveBeginGame2
      ),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
    this.stage.vars.meetingdesign = 0;
    this.costume = "background";
    this.createClone();
    this.costume = "button";
  }

  *whenIReceiveBeginGame() {
    if (this.costumeNumber === 1) {
      yield* this.wait(2);
    } else {
      yield* this.wait(2.3);
    }
    this.moveAhead();
  }

  *startAsClone() {
    this.costume = "background";
  }

  *whenIReceiveMeeting() {
    this.stage.vars.meetingdesign = 1;
  }

  *whenIReceiveDefeat() {
    this.stage.vars.meetingdesign = 0;
    /* TODO: Implement stop other scripts in sprite */ null;
    this.visible = false;
  }

  *whenIReceiveBeginGame2() {
    while (true) {
      this.goto(0, 0);
      if (this.toNumber(this.stage.vars.meetingdesign) === 1) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.costumeNumber === 2) {
      yield* this.startSound("Afro String2");
      this.broadcast("Emergency Meeting");
      this.stage.vars.meetingdesign = 0;
      this.stage.watchers.evidence.visible = true;
    } else {
      null;
    }
  }
}
